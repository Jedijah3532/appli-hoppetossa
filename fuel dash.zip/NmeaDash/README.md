# NMEA Dash — Hoppetossa

Prototype Android (Kotlin + Jetpack Compose, **minSdk 31 / Android 12**) qui affiche en temps
réel les données de tes instruments ST60 (profondeur, vitesse, vent) reçues via le
multiplexeur **Vela Navega NEA3WiFi**.

## Ce que fait ce prototype

- Se connecte au flux NMEA0183 du NEA3WiFi en **UDP** (par défaut) ou **TCP**, au choix.
- Parse les trames `DPT`/`DBT` (profondeur), `MWV` (vent), `VHW`/`VTG` (vitesse surface/fond).
- Affiche les valeurs sur un dashboard simple, mis à jour en direct.

Ce n'est volontairement **pas encore** un traceur AIS complet — mais l'alarme de mouillage
(voir plus bas) est maintenant incluse.

## Prérequis

- **Android Studio** (Iguana ou plus récent) avec JDK 17.
- Un téléphone/tablette **Android 12 (API 31) ou supérieur**, en USB debugging, ou un émulateur.
- Aucune dépendance externe à installer manuellement : Gradle télédownloadera tout au premier
  build (il faut donc une connexion internet la première fois, sur ton PC, pas sur le bateau).

## Ouvrir et lancer le projet

1. Décompresse l'archive.
2. Dans Android Studio : `File > Open`, sélectionne le dossier `NmeaDash`.
3. Laisse Gradle synchroniser (première fois : peut prendre quelques minutes).
4. Branche ton téléphone Android 12+ ou lance un émulateur, puis `Run > Run 'app'`.

## Se connecter au NEA3WiFi en conditions réelles

Deux cas de figure selon la configuration de ton multiplexeur :

### A) NEA3WiFi en mode point d'accès (par défaut)

- Sur ton téléphone, connecte-toi au réseau WiFi créé par le NEA3WiFi (SSID visible dans les
  réglages WiFi du téléphone, mot de passe par défaut `12345678` sauf si tu l'as changé).
- Dans l'appli, renseigne :
  - **IP** : `192.168.4.1`
  - **Port** : le port UDP configuré sur le multiplexeur (visible en te connectant à
    `http://192.168.4.1` depuis un navigateur — page de configuration du NEA3WiFi).
  - **Protocole** : UDP (recommandé — un seul client TCP peut se connecter à la fois sur le
    NEA3WiFi, donc si tu utilises déjà une autre appli en TCP, l'appli ne pourra pas se connecter).

### B) NEA3WiFi en mode "Client Station" (rejoint le réseau WiFi du bord)

- Connecte ton téléphone au même réseau WiFi que le NEA3WiFi.
- Renseigne l'IP attribuée au NEA3WiFi sur ce réseau (visible dans sa page de config, ou dans les
  logs de ton routeur/point d'accès de bord).

## Tester sans être sur le bateau

Tu peux simuler des trames NMEA en envoyant des paquets UDP depuis un PC sur le même réseau que
ton téléphone (utile pour valider l'appli avant de la tester en vrai) :

```bash
# Depuis un terminal Linux/Mac, en remplaçant <IP_TELEPHONE> et <PORT> :
echo -n '$IIDPT,3.5,0.0*7D' | nc -u -w1 <IP_TELEPHONE> <PORT>
echo -n '$IIMWV,045.0,R,12.3,N,A*3C' | nc -u -w1 <IP_TELEPHONE> <PORT>
echo -n '$IIVHW,,,,,05.2,N,,*XX' | nc -u -w1 <IP_TELEPHONE> <PORT>
```

(Les checksums ci-dessus sont indicatifs — le parseur tolère une trame sans `*hh` ou avec un
checksum incorrect en la traitant quand même, pour rester robuste avec du matériel réel.)

## Alarme de mouillage

Accessible via l'icône ⚓ en haut à droite du dashboard.

- **Mouiller ici** : mémorise ta position GPS actuelle (et la profondeur du moment) comme point d'ancre.
- **Rayon de sécurité** : choisis les conditions (Léger 3:1 / Modéré 5:1 / Fort 7:1) pour voir la longueur
  de chaîne suggérée selon la profondeur, puis règle le rayon d'alarme (ou utilise le rayon suggéré en
  un tap).
- **Enregistrement de trace** : choisis l'intervalle (1/5/10/30 min ou 1h) auquel la position est
  enregistrée pendant la surveillance.
- **Démarrer la surveillance** : lance un service en arrière-plan qui continue de tourner même écran
  éteint ou appli fermée (notification persistante). Si le bateau sort du rayon de sécurité, une alarme
  sonore + vibration continue se déclenche, avec un bouton "Arrêter l'alarme" dans la notification.
- **Visualisation** : un schéma hors-ligne (cercle de sécurité + trace GPS autour du point d'ancre,
  fonctionne toujours, même sans réseau) ou, si tu as du réseau (données mobiles), une vraie carte en
  ligne (OpenStreetMap via Leaflet) avec les mêmes informations.

- **Décalage antenne GPS / ancre** : l'antenne GPS de ton réseau NMEA est à ~7m du point où l'ancre
  touche le fond. Le rayon de sécurité suggéré intègre déjà cette marge. Limite connue : sans donnée
  de cap (compas), l'appli ne peut pas corriger géométriquement la position d'ancre enregistrée (elle
  capture la position de l'antenne au moment où tu appuies sur "Mouiller ici", pas la position exacte
  de l'ancre) — la marge de 7m absorbe cette imprécision côté rayon d'alarme, mais le point affiché sur
  la carte/le schéma peut être décalé de quelques mètres par rapport à l'ancre réelle.


- L'alarme sonore utilise le son d'alarme par défaut du téléphone ; pense à vérifier que le volume
  "Alarme" (pas juste "Notifications") est audible.
- Sur certains téléphones (notamment Xiaomi/Huawei/Samsung avec optimisation batterie agressive), il
  peut être nécessaire d'autoriser manuellement l'appli à tourner en arrière-plan sans restriction,
  sinon Android peut tuer le service après un moment.
- Pas encore d'intégration email/WhatsApp en cas d'alarme à distance (prévu pour une prochaine étape).

## Anthropic n'a pas accès au code d'Anchor Pro

Cette alarme de mouillage a été conçue à partir de principes de navigation classiques (formule de
Haversine, ratio chaîne/profondeur), pas d'un code propriétaire existant.

## Pistes d'évolution possibles

- Ajouter le décodage AIS (`!AIVDM`) et une carte des cibles.
- Sauvegarde de la trace GPS sur disque (survit à un redémarrage de l'appli).
- Alerte à distance par email/WhatsApp/SMS quand tu n'es pas à bord.
- Historique/graphes (profondeur au fil du temps, polaire de vent, etc.).

Dis-moi si tu veux qu'on avance sur l'une de ces pistes.

## Version 0.2 — Ordinateur de bord gazole

Icône pompe à essence à côté de l'ancre (ou carte « Gazole » du tableau de bord).

- Niveau estimé (L, cm, aiguille de sonde attendue), autonomie en heures et en milles.
- Trois consommateurs combinables : moteur 1200 tr/min, groupe 4 kW, Webasto 4 kW.
  Les heures sont comptées par horodatage : rien n'est perdu si l'appli est fermée.
- Milles parcourus moteur en marche (vitesse fond NMEA, ou GPS téléphone en secours) et
  conso au mille (fond et surface).
- Trip A / Trip B et horodateurs totaux (à régler dans les réglages).
- Plein (avec option « cuves pleines » qui sert de mesure) et Pige (bâbord, tribord
  facultatif, correction +2 cm, lecture sonde facultative pour affiner la zone morte).
- Les débits s'affinent à chaque mesure si au moins 25 L ont été consommés depuis la précédente.
- Alerte Telegram sous un seuil réglable, commande /gazole (quand la veille au mouillage tourne).
- Niveau de départ : 15,5 cm moyen ≈ 207 L.
