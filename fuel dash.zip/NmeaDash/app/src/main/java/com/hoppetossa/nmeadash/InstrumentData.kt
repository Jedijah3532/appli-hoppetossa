package com.hoppetossa.nmeadash

/**
 * Etat courant des instruments de bord, mis à jour au fil des trames NMEA0183 reçues.
 * Les valeurs restent nulles tant qu'aucune trame correspondante n'a été reçue.
 */
data class InstrumentData(
    val depthMeters: Double? = null,           // Profondeur sous transducteur (DBT/DPT)
    val speedThroughWaterKn: Double? = null,   // Vitesse surface / loch (VHW)
    val speedOverGroundKn: Double? = null,     // Vitesse fond / GPS (VTG/RMC)
    val windApparentAngleDeg: Double? = null,  // Angle du vent apparent (MWV, référence R)
    val windApparentSpeedKn: Double? = null,   // Vitesse du vent apparent
    val windTrueAngleDeg: Double? = null,      // Angle du vent réel (MWV, référence T)
    val windTrueSpeedKn: Double? = null,       // Vitesse du vent réel
    val latitude: Double? = null,              // Latitude en degrés décimaux (+ = N, - = S)
    val longitude: Double? = null,             // Longitude en degrés décimaux (+ = E, - = W)
    val courseOverGroundDeg: Double? = null,   // Route fond / COG (VTG/RMC) — fiable seulement en mouvement
    val lastSentenceAt: Long = 0L,             // Timestamp de la dernière trame reçue (ms)
    val lastRawSentence: String = ""           // Dernière trame brute (utile pour debug)
)

enum class ConnectionState { DISCONNECTED, CONNECTING, CONNECTED, ERROR }
