package com.hoppetossa.nmeadash

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.update

/**
 * Point d'accès unique à la connexion NMEA0183 (NEA3WiFi) et à l'état courant des instruments.
 *
 * Singleton volontaire : à la fois l'écran Dashboard et le service d'arrière-plan
 * "AnchorWatchService" (alarme de mouillage) doivent lire les mêmes données de position/vent
 * sans ouvrir deux connexions réseau séparées vers le multiplexeur.
 */
object NmeaRepository {

    // Portée de coroutine indépendante du cycle de vie d'une Activity : reste active tant que
    // le processus de l'appli tourne (y compris pendant que le service d'alarme est actif).
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.IO)

    var host: String = "192.168.4.1"
        private set
    var port: Int = 2000
        private set
    var protocol: NmeaProtocol = NmeaProtocol.UDP
        private set

    private val _data = MutableStateFlow(InstrumentData())
    val data: StateFlow<InstrumentData> = _data

    private val _connectionState = MutableStateFlow(ConnectionState.DISCONNECTED)
    val connectionState: StateFlow<ConnectionState> = _connectionState

    private val _statusMessage = MutableStateFlow<String?>(null)
    val statusMessage: StateFlow<String?> = _statusMessage

    private var receiver: NmeaReceiver? = null

    fun configure(host: String, port: Int, protocol: NmeaProtocol) {
        this.host = host
        this.port = port
        this.protocol = protocol
    }

    fun isActive(): Boolean =
        _connectionState.value == ConnectionState.CONNECTED || _connectionState.value == ConnectionState.CONNECTING

    fun connect() {
        if (isActive()) return

        receiver = NmeaReceiver(
            host = host,
            port = port,
            protocol = protocol,
            onLine = { line ->
                android.util.Log.d("NMEA_RAW", line)
                val updated = NmeaParser.parse(line, _data.value)
                if (updated != null) _data.update { updated }
            },
            onStateChange = { state, message ->
                _connectionState.value = state
                _statusMessage.value = message
            }
        ).also { it.start(scope) }
    }

    fun disconnect() {
        receiver?.stop()
        receiver = null
        _connectionState.value = ConnectionState.DISCONNECTED
    }
}
