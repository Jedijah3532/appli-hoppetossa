package com.hoppetossa.nmeadash

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Paramètres de l'alerte à distance par Telegram, persistés dans les SharedPreferences.
 * Le jeton de bot et l'identifiant de chat sont fournis par l'utilisateur (voir @BotFather).
 */
object TelegramSettings {
    private const val PREFS_NAME = "telegram_settings_prefs"
    private const val KEY_TOKEN = "bot_token"
    private const val KEY_CHAT_ID = "chat_id"
    private const val KEY_ENABLED = "enabled"

    private val _botToken = MutableStateFlow("")
    val botToken: StateFlow<String> = _botToken

    private val _chatId = MutableStateFlow("")
    val chatId: StateFlow<String> = _chatId

    private val _enabled = MutableStateFlow(false)
    val enabled: StateFlow<Boolean> = _enabled

    private var initialized = false

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        _botToken.value = prefs.getString(KEY_TOKEN, "") ?: ""
        _chatId.value = prefs.getString(KEY_CHAT_ID, "") ?: ""
        _enabled.value = prefs.getBoolean(KEY_ENABLED, false)
    }

    fun update(context: Context, token: String, chatId: String, enabled: Boolean) {
        _botToken.value = token
        _chatId.value = chatId
        _enabled.value = enabled
        context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
            .edit()
            .putString(KEY_TOKEN, token)
            .putString(KEY_CHAT_ID, chatId)
            .putBoolean(KEY_ENABLED, enabled)
            .apply()
    }

    fun isConfigured(): Boolean = _enabled.value && _botToken.value.isNotBlank() && _chatId.value.isNotBlank()
}
