package com.hoppetossa.nmeadash

import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import java.io.BufferedReader
import java.io.InputStreamReader
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import java.net.Socket
import java.net.SocketTimeoutException

enum class NmeaProtocol { UDP, TCP }

/**
 * Reçoit le flux NMEA0183 diffusé par le multiplexeur NEA3WiFi.
 *
 * - En UDP (mode par défaut du NEA3WiFi) : on se contente d'écouter le port choisi,
 *   pas besoin de connaître l'IP exacte du multiplexeur (broadcast sur le réseau du bord).
 * - En TCP : on ouvre une connexion socket vers l'IP:port du multiplexeur
 *   (ex: 192.168.4.1 si le téléphone est connecté directement au réseau WiFi du NEA3WiFi).
 *
 * onLine est appelé pour chaque ligne NMEA reçue (déjà "trim"ée).
 * onStateChange signale les changements d'état de connexion.
 */
class NmeaReceiver(
    private val host: String,
    private val port: Int,
    private val protocol: NmeaProtocol,
    private val onLine: (String) -> Unit,
    private val onStateChange: (ConnectionState, String?) -> Unit
) {
    private var job: Job? = null

    fun start(scope: CoroutineScope) {
        stop()
        job = scope.launch(Dispatchers.IO) {
            onStateChange(ConnectionState.CONNECTING, null)
            try {
                when (protocol) {
                    NmeaProtocol.UDP -> listenUdp()
                    NmeaProtocol.TCP -> listenTcp()
                }
            } catch (e: Exception) {
                onStateChange(ConnectionState.ERROR, e.message ?: "Erreur réseau")
            }
        }
    }

    fun stop() {
        job?.cancel()
        job = null
    }

    private suspend fun listenUdp() {
        val socket = DatagramSocket(null)
        socket.reuseAddress = true
        socket.soTimeout = 3000
        socket.bind(InetSocketAddress(port))
        socket.use { sock ->
            val buffer = ByteArray(2048)
            var announced = false
            while (kotlin.coroutines.coroutineContext.isActive) {
                try {
                    val packet = DatagramPacket(buffer, buffer.size)
                    sock.receive(packet)
                    if (!announced) {
                        onStateChange(ConnectionState.CONNECTED, null)
                        announced = true
                    }
                    val text = String(packet.data, 0, packet.length, Charsets.ISO_8859_1)
                    text.split("\r\n", "\n").forEach { line ->
                        if (line.isNotBlank()) onLine(line)
                    }
                } catch (e: SocketTimeoutException) {
                    // Pas de donnée reçue dans le délai : on continue d'attendre, sans planter
                    if (!announced) onStateChange(ConnectionState.CONNECTING, "En attente de données UDP…")
                }
            }
        }
    }

    private suspend fun listenTcp() {
        Socket().use { socket ->
            socket.connect(InetSocketAddress(host, port), 5000)
            onStateChange(ConnectionState.CONNECTED, null)
            val reader = BufferedReader(InputStreamReader(socket.getInputStream(), Charsets.ISO_8859_1))
            while (kotlin.coroutines.coroutineContext.isActive) {
                val line = reader.readLine() ?: break
                if (line.isNotBlank()) onLine(line)
            }
            onStateChange(ConnectionState.DISCONNECTED, "Connexion TCP fermée par le multiplexeur")
        }
    }
}
