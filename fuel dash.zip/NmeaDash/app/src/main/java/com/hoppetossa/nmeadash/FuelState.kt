package com.hoppetossa.nmeadash

import android.content.Context
import android.content.Intent
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject
import java.util.Locale
import kotlin.math.max

/** Formatage à la française (virgule décimale). */
fun fr(format: String, vararg args: Any?): String = String.format(Locale.FRANCE, format, *args)

/** "2 h 05" à partir d'une durée en millisecondes. */
fun formatDuration(ms: Long): String {
    val totalMin = ms / 60_000
    return fr("%d h %02d", totalMin / 60, totalMin % 60)
}

/** Lit un nombre saisi avec virgule ou point. */
fun String.toDoubleFr(): Double? = replace(',', '.').trim().toDoubleOrNull()

/**
 * Etat partagé de l'ordinateur de bord gazole, lu par l'écran Carburant, le service FuelService
 * et les commandes Telegram. Persisté en JSON dans les SharedPreferences.
 *
 * Les temps de marche reposent sur des horodatages (heure de mise en marche enregistrée) :
 * même si l'appli est tuée, aucune heure moteur n'est perdue.
 */
object FuelState {
    private const val PREFS_NAME = "fuel_prefs"
    private const val KEY_DATA = "fuel_json"
    private const val MS_PER_HOUR = 3_600_000.0

    private var appContext: Context? = null
    private var initialized = false

    private val _data = MutableStateFlow(defaultData())
    val data: StateFlow<FuelData> = _data

    /** Vitesse fond lissée (mise à jour par FuelService quand le moteur tourne). */
    private val _smoothedSogKn = MutableStateFlow<Double?>(null)
    val smoothedSogKn: StateFlow<Double?> = _smoothedSogKn

    fun init(context: Context) {
        if (initialized) return
        initialized = true
        appContext = context.applicationContext
        val json = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE).getString(KEY_DATA, null)
        if (json != null) {
            fromJson(json)?.let { _data.value = it }
        } else {
            persist(_data.value)
        }
    }

    private fun defaultData(): FuelData {
        val now = System.currentTimeMillis()
        val s = FuelSettings()
        val initialHeight = 15.5 // moyenne bâbord 20 cm / tribord 11 cm, bateau gîté
        return FuelData(
            levelAtRefL = initialHeight * s.litersPerCm,
            refAt = now,
            consumers = FuelConsumer.values().associateWith { ConsumerData(rateLph = it.defaultRateLph) },
            tripA = TripData(now),
            tripB = TripData(now),
            settings = s
        ).withEvent(now, fr("Niveau initial : %.1f cm moyen ≈ %.0f L", initialHeight, initialHeight * s.litersPerCm))
    }

    // ---------------------------------------------------------------------------------------
    // Calculs (fonctions pures, appelées avec l'heure courante pour l'affichage en direct)
    // ---------------------------------------------------------------------------------------

    fun openMs(c: ConsumerData, now: Long): Long = c.runningSince?.let { max(0L, now - it) } ?: 0L

    fun isRunning(d: FuelData, type: FuelConsumer): Boolean = d.consumers[type]?.runningSince != null

    fun anyRunning(d: FuelData = _data.value): Boolean = d.consumers.values.any { it.runningSince != null }

    fun rate(d: FuelData, type: FuelConsumer): Double = d.consumers[type]?.rateLph ?: type.defaultRateLph

    /**
     * Débit moteur. Aujourd'hui : débit appris à 1200 tr/min.
     * Plus tard (NMEA 2000, PGN 127488) : débit selon le régime réel — seul ce point sera à modifier.
     */
    fun engineRateLph(d: FuelData): Double = rate(d, FuelConsumer.ENGINE)

    fun levelL(d: FuelData, now: Long): Double =
        d.levelAtRefL + d.fillsSinceRefL - d.consumers.values.sumOf {
            it.litersSincePige + it.rateLph * openMs(it, now) / MS_PER_HOUR
        }

    fun heightCm(d: FuelData, now: Long): Double = levelL(d, now) / d.settings.litersPerCm

    /** Position théorique de l'aiguille de la sonde (cm sur 45), bateau à plat. */
    fun gaugeCm(d: FuelData, now: Long): Double =
        (heightCm(d, now) - d.settings.deadZoneCm).coerceIn(0.0, d.settings.gaugeRangeCm)

    fun instantRateLph(d: FuelData): Double =
        d.consumers.values.filter { it.runningSince != null }.sumOf { it.rateLph }

    fun totalMs(d: FuelData, type: FuelConsumer, now: Long): Long {
        val c = d.consumers[type] ?: return 0L
        return c.totalMs + openMs(c, now)
    }

    fun tripMs(d: FuelData, trip: TripData, type: FuelConsumer, now: Long): Long {
        val c = d.consumers[type] ?: return trip.ms[type] ?: 0L
        return (trip.ms[type] ?: 0L) + openMs(c, now)
    }

    fun tripLiters(d: FuelData, trip: TripData, type: FuelConsumer, now: Long): Double {
        val c = d.consumers[type] ?: return trip.liters[type] ?: 0.0
        return (trip.liters[type] ?: 0.0) + c.rateLph * openMs(c, now) / MS_PER_HOUR
    }

    fun tripCost(d: FuelData, trip: TripData, now: Long): Double =
        trip.cost + d.consumers.values.sumOf { it.rateLph * openMs(it, now) / MS_PER_HOUR } * d.settings.pricePerLiter

    /** Vitesse fond : NMEA en priorité, sinon GPS du téléphone. */
    fun currentSogKn(): Double? {
        val now = System.currentTimeMillis()
        val nmea = NmeaRepository.data.value
        if (NmeaRepository.connectionState.value == ConnectionState.CONNECTED &&
            nmea.speedOverGroundKn != null && now - nmea.lastSentenceAt < 10_000
        ) return nmea.speedOverGroundKn
        val loc = PositionRepository.phoneLocation.value
        if (loc != null && loc.hasSpeed() && now - loc.time < 15_000) return loc.speed * 1.943844
        return null
    }

    // ---------------------------------------------------------------------------------------
    // Actions
    // ---------------------------------------------------------------------------------------

    @Synchronized
    private fun mutate(block: (FuelData) -> FuelData) {
        val updated = block(_data.value)
        _data.value = updated
        persist(updated)
    }

    /** Arrête les compteurs "en cours" à l'instant [now] et les verse dans les cumuls. */
    private fun checkpoint(d: FuelData, now: Long): FuelData {
        var tripA = d.tripA
        var tripB = d.tripB
        val consumers = d.consumers.mapValues { (type, c) ->
            val since = c.runningSince ?: return@mapValues c
            val dt = max(0L, now - since)
            val liters = c.rateLph * dt / MS_PER_HOUR
            tripA = tripA.addUsage(type, dt, liters, d.settings.pricePerLiter)
            tripB = tripB.addUsage(type, dt, liters, d.settings.pricePerLiter)
            c.copy(
                runningSince = now,
                totalMs = c.totalMs + dt,
                msSincePige = c.msSincePige + dt,
                litersSincePige = c.litersSincePige + liters
            )
        }
        return d.copy(consumers = consumers, tripA = tripA, tripB = tripB)
    }

    private fun refreshAlertFlag(d: FuelData, now: Long): FuelData =
        if (d.lowAlertSent && levelL(d, now) > d.settings.alertThresholdL + 5.0) d.copy(lowAlertSent = false) else d

    fun toggle(type: FuelConsumer) {
        val now = System.currentTimeMillis()
        mutate { d ->
            val cp = checkpoint(d, now)
            val c = cp.consumers.getValue(type)
            if (c.runningSince == null) {
                cp.copy(consumers = cp.consumers + (type to c.copy(runningSince = now)))
                    .withEvent(now, "${type.label} : marche")
            } else {
                val sessionStart = d.consumers.getValue(type).runningSince ?: now
                cp.copy(consumers = cp.consumers + (type to c.copy(runningSince = null)))
                    .withEvent(now, "${type.label} : arrêt après ${formatDuration(now - sessionStart)}")
            }
        }
        syncService()
    }

    /** Démarre ou arrête le service d'arrière-plan selon qu'un consommateur tourne. */
    fun syncService() {
        val ctx = appContext ?: return
        val intent = Intent(ctx, FuelService::class.java)
        if (anyRunning()) {
            try {
                ctx.startForegroundService(intent)
            } catch (e: Exception) {
                android.util.Log.e("FuelState", "Impossible de démarrer FuelService", e)
            }
        } else {
            ctx.stopService(intent)
            _smoothedSogKn.value = null
        }
    }

    fun addFill(liters: Double, pricePerLiter: Double?, tanksFull: Boolean) {
        val now = System.currentTimeMillis()
        mutate { d ->
            val settings = if (pricePerLiter != null) d.settings.copy(pricePerLiter = pricePerLiter) else d.settings
            var cp = checkpoint(d, now).copy(settings = settings)
            cp = cp.copy(fillsSinceRefL = cp.fillsSinceRefL + liters)
                .withEvent(now, fr("Plein : +%.0f L à %.2f €/L (%.0f €)", liters, settings.pricePerLiter, liters * settings.pricePerLiter))
            if (tanksFull) cp = applyMeasurement(cp, settings.capacityL, now, "Cuves pleines")
            refreshAlertFlag(cp, now)
        }
    }

    /**
     * Saisie d'une mesure de hauteur.
     * [portIsPige]/[starboardIsPige] : true = lecture de pige (on ajoute la correction de 2 cm).
     * [probeCm] : lecture facultative de la sonde (côté tribord), pour affiner la zone morte.
     */
    fun addDipMeasurement(
        portCm: Double,
        portIsPige: Boolean,
        starboardCm: Double?,
        starboardIsPige: Boolean,
        probeCm: Double?
    ) {
        val now = System.currentTimeMillis()
        mutate { d ->
            val s = d.settings
            val portReal = portCm + if (portIsPige) s.pigeOffsetCm else 0.0
            val starboardReal = starboardCm?.let { it + if (starboardIsPige) s.pigeOffsetCm else 0.0 }
            val avg = if (starboardReal != null) (portReal + starboardReal) / 2.0 else portReal

            var cp = checkpoint(d, now)
            val label = if (starboardReal != null)
                fr("Pige bâbord %.1f / tribord %.1f cm → moyenne %.1f cm", portReal, starboardReal, avg)
            else fr("Pige bâbord %.1f cm (bateau à plat)", portReal)
            cp = cp.withEvent(now, label)

            if (probeCm != null) {
                val sideHeight = starboardReal ?: portReal
                val sample = sideHeight - probeCm
                if (sample in 0.0..15.0) {
                    val newDz = (cp.settings.deadZoneCm + sample) / 2.0
                    cp = cp.copy(settings = cp.settings.copy(deadZoneCm = newDz))
                        .withEvent(now, fr("Zone morte sonde : mesurée %.1f cm → retenue %.1f cm", sample, newDz))
                } else {
                    cp = cp.withEvent(now, fr("Lecture sonde incohérente (écart %.1f cm) : ignorée", sample))
                }
            }
            refreshAlertFlag(applyMeasurement(cp, avg * s.litersPerCm, now, "Mesure"), now)
        }
    }

    /** Recale le niveau sur une mesure et affine les débits (voir FUEL_MIN_LEARN_LITERS). */
    private fun applyMeasurement(d: FuelData, measuredL: Double, now: Long, label: String): FuelData {
        val estimated = levelL(d, now)
        val actual = d.levelAtRefL + d.fillsSinceRefL - measuredL
        val hours = d.consumers.mapValues { it.value.msSincePige / MS_PER_HOUR }
        val active = hours.filter { it.value >= 0.05 }
        var consumers = d.consumers
        val notes = mutableListOf(
            fr("%s : %.0f L mesurés (estimé %.0f L, écart %+.0f L)", label, measuredL, estimated, measuredL - estimated)
        )

        when {
            active.isEmpty() -> notes += "Aucun consommateur depuis la dernière mesure : débits inchangés"
            actual < FUEL_MIN_LEARN_LITERS -> notes += fr(
                "Consommation trop faible (%.0f L) pour affiner les débits : il faut au moins %.0f L entre deux mesures",
                actual, FUEL_MIN_LEARN_LITERS
            )
            else -> {
                var target: FuelConsumer? = null
                var sample = 0.0
                if (active.size == 1) {
                    target = active.keys.first()
                    sample = actual / active.values.first()
                } else if (FuelConsumer.ENGINE in active) {
                    val others = active.filterKeys { it != FuelConsumer.ENGINE }.entries
                        .sumOf { rate(d, it.key) * it.value }
                    target = FuelConsumer.ENGINE
                    sample = (actual - others) / active.getValue(FuelConsumer.ENGINE)
                } else {
                    notes += "Groupe et Webasto ensemble sans moteur : impossible de les séparer, débits inchangés"
                }
                if (target != null) {
                    val h = hours.getValue(target)
                    val c = consumers.getValue(target)
                    if (sample < target.minRateLph || sample > target.maxRateLph) {
                        notes += fr("%s : %.2f L/h mesurés, hors plage plausible — ignoré (vérifie la mesure)", target.label, sample)
                    } else {
                        val w = c.calibHours.coerceAtMost(30.0)
                        val newRate = (c.rateLph * w + sample * h) / (w + h)
                        consumers = consumers + (target to c.copy(rateLph = newRate, calibHours = c.calibHours + h))
                        notes += fr("%s : %.2f L/h mesurés → débit retenu %.2f L/h", target.label, sample, newRate)
                    }
                }
            }
        }

        consumers = consumers.mapValues { it.value.copy(msSincePige = 0L, litersSincePige = 0.0) }
        var out = d.copy(levelAtRefL = measuredL, refAt = now, fillsSinceRefL = 0.0, consumers = consumers)
        notes.forEach { out = out.withEvent(now, it) }
        return out
    }

    fun updateSettings(
        settings: FuelSettings,
        rates: Map<FuelConsumer, Double>,
        totalHours: Map<FuelConsumer, Double>
    ) {
        val now = System.currentTimeMillis()
        mutate { d ->
            val cp = checkpoint(d, now)
            val consumers = cp.consumers.mapValues { (type, c) ->
                var nc = c
                rates[type]?.let { r -> if (kotlin.math.abs(r - c.rateLph) > 0.005) nc = nc.copy(rateLph = r, calibHours = FUEL_PRIOR_HOURS) }
                totalHours[type]?.let { h ->
                    val ms = (h * MS_PER_HOUR).toLong()
                    if (kotlin.math.abs(ms - c.totalMs) > 60_000) nc = nc.copy(totalMs = ms)
                }
                nc
            }
            refreshAlertFlag(cp.copy(settings = settings, consumers = consumers).withEvent(now, "Réglages modifiés"), now)
        }
    }

    fun resetTrip(isTripA: Boolean) {
        val now = System.currentTimeMillis()
        mutate { d ->
            val cp = checkpoint(d, now)
            if (isTripA) cp.copy(tripA = TripData(now)).withEvent(now, "Trip A remis à zéro")
            else cp.copy(tripB = TripData(now)).withEvent(now, "Trip B remis à zéro")
        }
    }

    /** Appelé par FuelService : milles parcourus moteur en marche. */
    fun addDistance(nm: Double) {
        if (nm <= 0.0) return
        mutate { d ->
            d.copy(
                tripA = d.tripA.copy(distanceNm = d.tripA.distanceNm + nm),
                tripB = d.tripB.copy(distanceNm = d.tripB.distanceNm + nm)
            )
        }
    }

    /** Lissage exponentiel (~1 min) pour éviter que la conso au mille saute avec la houle. */
    fun updateSmoothedSog(sogKn: Double?) {
        if (sogKn == null) {
            _smoothedSogKn.value = null
            return
        }
        val prev = _smoothedSogKn.value
        _smoothedSogKn.value = if (prev == null) sogKn else prev * 0.9 + sogKn * 0.1
    }

    /** Renvoie le texte d'alerte si le seuil vient d'être franchi (une seule fois par passage). */
    fun checkLowAlert(now: Long): String? {
        val current = _data.value
        if (!current.settings.alertEnabled || current.lowAlertSent ||
            levelL(current, now) >= current.settings.alertThresholdL
        ) return null
        var message: String? = null
        mutate { d ->
            val level = levelL(d, now)
            if (d.settings.alertEnabled && !d.lowAlertSent && level < d.settings.alertThresholdL) {
                message = "⛽ ALERTE GAZOLE — Hoppetossa\n" + telegramSummary(d, now)
                d.copy(lowAlertSent = true).withEvent(now, fr("Alerte niveau bas envoyée (%.0f L)", level))
            } else d
        }
        return message
    }

    fun telegramSummary(d: FuelData = _data.value, now: Long = System.currentTimeMillis()): String {
        val s = d.settings
        val level = levelL(d, now).coerceAtLeast(0.0)
        val engine = engineRateLph(d)
        val running = FuelConsumer.values().filter { isRunning(d, it) }
        val runningText = if (running.isEmpty()) "aucun" else running.joinToString(", ") {
            it.label + " (" + formatDuration(openMs(d.consumers.getValue(it), now)) + ")"
        }
        return fr("Gazole : %.0f L (%.1f cm moyen)\n", level, level / s.litersPerCm) +
            fr("Autonomie moteur : %.0f h ≈ %.0f nm à %.1f nd\n", level / engine, level / engine * s.cruiseSpeedKn, s.cruiseSpeedKn) +
            fr("Avant réserve (jauge à 0) : %.0f h\n", (level - s.deadZoneL).coerceAtLeast(0.0) / engine) +
            "En marche : $runningText"
    }

    fun notificationText(d: FuelData = _data.value, now: Long = System.currentTimeMillis()): String {
        val running = FuelConsumer.values().filter { isRunning(d, it) }
            .joinToString(" · ") { it.label.substringBefore(" ") + " " + formatDuration(openMs(d.consumers.getValue(it), now)) }
        return fr("%.0f L restants", levelL(d, now).coerceAtLeast(0.0)) + if (running.isNotEmpty()) " — $running" else ""
    }

    // ---------------------------------------------------------------------------------------
    // Persistance JSON
    // ---------------------------------------------------------------------------------------

    private fun persist(d: FuelData) {
        val ctx = appContext ?: return
        try {
            ctx.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
                .edit().putString(KEY_DATA, toJson(d).toString()).apply()
        } catch (e: Exception) {
            android.util.Log.e("FuelState", "Erreur de sauvegarde", e)
        }
    }

    private fun tripToJson(t: TripData): JSONObject = JSONObject().apply {
        put("start", t.startedAt)
        put("ms", JSONObject().apply { t.ms.forEach { (k, v) -> put(k.name, v) } })
        put("liters", JSONObject().apply { t.liters.forEach { (k, v) -> put(k.name, v) } })
        put("dist", t.distanceNm)
        put("cost", t.cost)
    }

    private fun tripFromJson(o: JSONObject?, fallbackStart: Long): TripData {
        if (o == null) return TripData(fallbackStart)
        val msObj = o.optJSONObject("ms")
        val litersObj = o.optJSONObject("liters")
        val ms = mutableMapOf<FuelConsumer, Long>()
        val liters = mutableMapOf<FuelConsumer, Double>()
        FuelConsumer.values().forEach { c ->
            if (msObj != null && msObj.has(c.name)) ms[c] = msObj.getLong(c.name)
            if (litersObj != null && litersObj.has(c.name)) liters[c] = litersObj.getDouble(c.name)
        }
        return TripData(
            startedAt = o.optLong("start", fallbackStart),
            ms = ms,
            liters = liters,
            distanceNm = o.optDouble("dist", 0.0),
            cost = o.optDouble("cost", 0.0)
        )
    }

    private fun toJson(d: FuelData): JSONObject = JSONObject().apply {
        put("levelAtRef", d.levelAtRefL)
        put("refAt", d.refAt)
        put("fills", d.fillsSinceRefL)
        put("lowAlertSent", d.lowAlertSent)
        put("consumers", JSONObject().apply {
            d.consumers.forEach { (k, c) ->
                put(k.name, JSONObject().apply {
                    put("rate", c.rateLph)
                    put("calib", c.calibHours)
                    put("running", c.runningSince ?: JSONObject.NULL)
                    put("total", c.totalMs)
                    put("msPige", c.msSincePige)
                    put("lPige", c.litersSincePige)
                })
            }
        })
        put("tripA", tripToJson(d.tripA))
        put("tripB", tripToJson(d.tripB))
        val s = d.settings
        put("settings", JSONObject().apply {
            put("lpcm", s.litersPerCmPerTank)
            put("tanks", s.tankCount)
            put("depth", s.tankDepthCm)
            put("deadZone", s.deadZoneCm)
            put("gaugeRange", s.gaugeRangeCm)
            put("pigeOffset", s.pigeOffsetCm)
            put("price", s.pricePerLiter)
            put("alertL", s.alertThresholdL)
            put("alertOn", s.alertEnabled)
            put("cruise", s.cruiseSpeedKn)
        })
        put("history", JSONArray().apply {
            d.history.forEach { e -> put(JSONObject().apply { put("t", e.time); put("x", e.text) }) }
        })
    }

    private fun fromJson(json: String): FuelData? = try {
        val o = JSONObject(json)
        val now = System.currentTimeMillis()
        val def = FuelSettings()
        val so = o.optJSONObject("settings") ?: JSONObject()
        val settings = FuelSettings(
            litersPerCmPerTank = so.optDouble("lpcm", def.litersPerCmPerTank),
            tankCount = so.optInt("tanks", def.tankCount),
            tankDepthCm = so.optDouble("depth", def.tankDepthCm),
            deadZoneCm = so.optDouble("deadZone", def.deadZoneCm),
            gaugeRangeCm = so.optDouble("gaugeRange", def.gaugeRangeCm),
            pigeOffsetCm = so.optDouble("pigeOffset", def.pigeOffsetCm),
            pricePerLiter = so.optDouble("price", def.pricePerLiter),
            alertThresholdL = so.optDouble("alertL", def.alertThresholdL),
            alertEnabled = so.optBoolean("alertOn", def.alertEnabled),
            cruiseSpeedKn = so.optDouble("cruise", def.cruiseSpeedKn)
        )
        val co = o.optJSONObject("consumers") ?: JSONObject()
        val consumers = FuelConsumer.values().associateWith { type ->
            val c = co.optJSONObject(type.name)
            if (c == null) ConsumerData(rateLph = type.defaultRateLph)
            else ConsumerData(
                rateLph = c.optDouble("rate", type.defaultRateLph),
                calibHours = c.optDouble("calib", FUEL_PRIOR_HOURS),
                runningSince = if (c.isNull("running")) null else c.optLong("running"),
                totalMs = c.optLong("total", 0L),
                msSincePige = c.optLong("msPige", 0L),
                litersSincePige = c.optDouble("lPige", 0.0)
            )
        }
        val ha = o.optJSONArray("history") ?: JSONArray()
        val history = (0 until ha.length()).map { i ->
            val e = ha.getJSONObject(i)
            FuelEvent(e.optLong("t"), e.optString("x"))
        }
        FuelData(
            levelAtRefL = o.getDouble("levelAtRef"),
            refAt = o.optLong("refAt", now),
            fillsSinceRefL = o.optDouble("fills", 0.0),
            consumers = consumers,
            tripA = tripFromJson(o.optJSONObject("tripA"), now),
            tripB = tripFromJson(o.optJSONObject("tripB"), now),
            settings = settings,
            history = history,
            lowAlertSent = o.optBoolean("lowAlertSent", false)
        )
    } catch (e: Exception) {
        android.util.Log.e("FuelState", "Données carburant illisibles, valeurs par défaut", e)
        null
    }
}
