package com.hoppetossa.nmeadash

import android.content.Context
import android.location.Location
import android.location.LocationListener
import android.location.LocationManager
import android.os.Bundle
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn

enum class PositionSource { NMEA, PHONE_GPS }

data class PositionFix(
    val latitude: Double,
    val longitude: Double,
    val source: PositionSource
)

/**
 * Position "effective" du bateau : celle du réseau NMEA (NEA3WiFi) en priorité, ou celle du
 * GPS du téléphone en secours si le réseau NMEA n'est pas connecté / ne fournit pas de position
 * (utile à quai avant de brancher le multiplexeur, ou en cas de coupure WiFi).
 */
object PositionRepository {

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)

    private val _phoneLocation = MutableStateFlow<Location?>(null)
    val phoneLocation: StateFlow<Location?> = _phoneLocation

    private var locationManager: LocationManager? = null
    private var listener: LocationListener? = null
    private var started = false

    /** A appeler une fois avec un Context applicatif, après que la permission localisation soit accordée. */
    fun startPhoneGps(context: Context) {
        if (started) return
        started = true
        locationManager = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager
        listener = object : LocationListener {
            override fun onLocationChanged(location: Location) {
                _phoneLocation.value = location
            }
            @Deprecated("Deprecated in Java")
            override fun onStatusChanged(provider: String?, status: Int, extras: Bundle?) {}
            override fun onProviderEnabled(provider: String) {}
            override fun onProviderDisabled(provider: String) {}
        }
        try {
            locationManager?.let { lm ->
                if (lm.isProviderEnabled(LocationManager.GPS_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.GPS_PROVIDER, 3000L, 5f, listener!!)
                }
                if (lm.isProviderEnabled(LocationManager.NETWORK_PROVIDER)) {
                    lm.requestLocationUpdates(LocationManager.NETWORK_PROVIDER, 3000L, 5f, listener!!)
                }
            }
        } catch (e: SecurityException) {
            // Permission pas encore accordée : on réessaiera au prochain appel une fois accordée.
            started = false
        }
    }

    /**
     * Flux combiné : position NMEA si le réseau est connecté et fournit une position, sinon
     * position du GPS téléphone si disponible, sinon null.
     */
    val currentFix: StateFlow<PositionFix?> = combine(
        NmeaRepository.data,
        NmeaRepository.connectionState,
        _phoneLocation
    ) { instrument, connectionState, phoneLoc ->
        val nmeaLat = instrument.latitude
        val nmeaLon = instrument.longitude
        if (connectionState == ConnectionState.CONNECTED && nmeaLat != null && nmeaLon != null) {
            PositionFix(nmeaLat, nmeaLon, PositionSource.NMEA)
        } else if (phoneLoc != null) {
            PositionFix(phoneLoc.latitude, phoneLoc.longitude, PositionSource.PHONE_GPS)
        } else {
            null
        }
    }.stateIn(scope, SharingStarted.Eagerly, null)
}
