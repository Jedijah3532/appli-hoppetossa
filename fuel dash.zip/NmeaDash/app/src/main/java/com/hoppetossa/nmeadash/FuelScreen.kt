package com.hoppetossa.nmeadash

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val SableFonce = Color(0xFFD4C4A0)

@Composable
fun FuelScreen(onBack: () -> Unit) {
    val data by FuelState.data.collectAsState()
    val smoothedSog by FuelState.smoothedSogKn.collectAsState()
    val instrument by NmeaRepository.data.collectAsState()

    // Horloge pour les chronos en direct
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(1_000)
        }
    }

    var showFill by remember { mutableStateOf(false) }
    var showDip by remember { mutableStateOf(false) }
    var showSettings by remember { mutableStateOf(false) }
    var tripToReset by remember { mutableStateOf<Boolean?>(null) } // true = A, false = B

    val s = data.settings
    val level = FuelState.levelL(data, now).coerceAtLeast(0.0)
    val height = level / s.litersPerCm
    val instant = FuelState.instantRateLph(data)
    val engineRate = FuelState.engineRateLph(data)
    val engineOn = FuelState.isRunning(data, FuelConsumer.ENGINE)
    val sog = smoothedSog
    val stw = instrument.speedThroughWaterKn

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.fillMaxWidth()) {
            IconButton(onClick = onBack) { Icon(Icons.Filled.ArrowBack, contentDescription = "Retour") }
            Text("Ordinateur de bord", fontSize = 22.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
            IconButton(onClick = { showSettings = true }) { Icon(Icons.Filled.Settings, contentDescription = "Réglages") }
        }
        Spacer(Modifier.height(12.dp))

        // ---- Niveau ----
        Card(modifier = Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.Bottom) {
                    Text(fr("%.0f L", level), fontSize = 40.sp, fontWeight = FontWeight.Bold)
                    Spacer(Modifier.width(12.dp))
                    Text(
                        fr("%.1f cm moyen · %.0f €", height, level * s.pricePerLiter),
                        fontSize = 14.sp,
                        modifier = Modifier.padding(bottom = 8.dp)
                    )
                }
                Spacer(Modifier.height(8.dp))
                LevelBar(fraction = (level / s.capacityL).toFloat(), reserveFraction = (s.deadZoneL / s.capacityL).toFloat())
                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text(fr("Réserve (jauge 0) %.0f L", s.deadZoneL), fontSize = 12.sp)
                    Text(fr("%.0f L", s.capacityL), fontSize = 12.sp)
                }
                Spacer(Modifier.height(6.dp))
                val gauge = FuelState.gaugeCm(data, now)
                Text(
                    fr("Aiguille sonde attendue (à plat) : %.1f / %.0f cm (%s)", gauge, s.gaugeRangeCm, gaugeFractionText(gauge / s.gaugeRangeCm)),
                    fontSize = 13.sp
                )
            }
        }
        Spacer(Modifier.height(12.dp))

        // ---- Conso et autonomie ----
        Row(Modifier.fillMaxWidth()) {
            MetricCard(
                label = "Conso instantanée",
                value = if (instant > 0) fr("%.1f L/h", instant) else "—",
                sub = when {
                    engineOn && sog != null && sog > 0.5 -> fr("%.2f L/nm fond", instant / sog)
                    else -> null
                },
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            val autonomyRate = if (instant > 0) instant else engineRate
            MetricCard(
                label = "Autonomie",
                value = fr("%.0f h", level / autonomyRate),
                sub = if (engineOn && sog != null && sog > 0.5)
                    fr("≈ %.0f nm à %.1f nd", level / instant * sog, sog)
                else fr("≈ %.0f nm à %.1f nd", level / engineRate * s.cruiseSpeedKn, s.cruiseSpeedKn),
                modifier = Modifier.weight(1f)
            )
        }
        Spacer(Modifier.height(12.dp))
        Row(Modifier.fillMaxWidth()) {
            val autonomyRate = if (instant > 0) instant else engineRate
            MetricCard(
                label = "Avant réserve",
                value = fr("%.0f h", (level - s.deadZoneL).coerceAtLeast(0.0) / autonomyRate),
                sub = fr("%.0f L au-dessus du 0", (level - s.deadZoneL).coerceAtLeast(0.0)),
                modifier = Modifier.weight(1f)
            )
            Spacer(Modifier.width(12.dp))
            MetricCard(
                label = "Vitesse",
                value = sog?.let { fr("%.1f nd fond", it) } ?: "—",
                sub = if (engineOn && stw != null && stw > 0.5) fr("%.1f nd surface · %.2f L/nm", stw, instant / stw)
                else stw?.let { fr("%.1f nd surface", it) },
                modifier = Modifier.weight(1f)
            )
        }

        // ---- Consommateurs ----
        Spacer(Modifier.height(20.dp))
        Text("Consommateurs", fontSize = 16.sp, fontWeight = FontWeight.Bold)
        Spacer(Modifier.height(8.dp))
        FuelConsumer.values().forEach { type ->
            val c = data.consumers.getValue(type)
            ConsumerToggle(
                label = type.label,
                rate = c.rateLph,
                running = c.runningSince != null,
                elapsedMs = FuelState.openMs(c, now),
                onClick = { FuelState.toggle(type) }
            )
            Spacer(Modifier.height(8.dp))
        }

        // ---- Plein / Pige ----
        Spacer(Modifier.height(8.dp))
        Row(Modifier.fillMaxWidth()) {
            Button(onClick = { showFill = true }, modifier = Modifier.weight(1f)) { Text("Plein") }
            Spacer(Modifier.width(12.dp))
            Button(onClick = { showDip = true }, modifier = Modifier.weight(1f)) { Text("Pige") }
        }

        // ---- Trips ----
        Spacer(Modifier.height(20.dp))
        TripCard("Trip A", data, data.tripA, now) { tripToReset = true }
        Spacer(Modifier.height(12.dp))
        TripCard("Trip B", data, data.tripB, now) { tripToReset = false }

        // ---- Horodateurs ----
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Horodateurs totaux", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                FuelConsumer.values().forEach { type ->
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text(type.label, fontSize = 14.sp)
                        Text(formatDuration(FuelState.totalMs(data, type, now)), fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                    }
                }
            }
        }

        // ---- Historique ----
        Spacer(Modifier.height(12.dp))
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp)) {
                Text("Historique", fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Spacer(Modifier.height(6.dp))
                val dateFormat = remember { SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE) }
                data.history.take(25).forEach { e ->
                    Text("${dateFormat.format(Date(e.time))}  ${e.text}", fontSize = 12.sp, modifier = Modifier.padding(vertical = 2.dp))
                }
            }
        }
        Spacer(Modifier.height(24.dp))
    }

    if (showFill) FillDialog(s.pricePerLiter, s.capacityL, onDismiss = { showFill = false }) { liters, price, full ->
        FuelState.addFill(liters, price, full)
        showFill = false
    }
    if (showDip) DipDialog(s, onDismiss = { showDip = false }) { port, portPige, starboard, starboardPige, probe ->
        FuelState.addDipMeasurement(port, portPige, starboard, starboardPige, probe)
        showDip = false
    }
    if (showSettings) SettingsDialog(data, now, onDismiss = { showSettings = false })
    tripToReset?.let { isA ->
        AlertDialog(
            onDismissRequest = { tripToReset = null },
            title = { Text("Remettre le ${if (isA) "Trip A" else "Trip B"} à zéro ?") },
            text = { Text("Les heures, litres, milles et coût de ce trip repartent de zéro. Les horodateurs totaux ne changent pas.") },
            confirmButton = { TextButton(onClick = { FuelState.resetTrip(isA); tripToReset = null }) { Text("Remettre à zéro") } },
            dismissButton = { TextButton(onClick = { tripToReset = null }) { Text("Annuler") } }
        )
    }
}

private fun gaugeFractionText(f: Double): String = when {
    f <= 0.02 -> "0"
    f < 0.20 -> "moins de 1/4"
    f < 0.30 -> "≈ 1/4"
    f < 0.45 -> "entre 1/4 et 1/2"
    f < 0.55 -> "≈ 1/2"
    f < 0.70 -> "entre 1/2 et 3/4"
    f < 0.80 -> "≈ 3/4"
    f < 0.97 -> "plus de 3/4"
    else -> "plein"
}

@Composable
private fun LevelBar(fraction: Float, reserveFraction: Float) {
    BoxWithConstraints(
        Modifier
            .fillMaxWidth()
            .height(14.dp)
            .clip(RoundedCornerShape(7.dp))
            .background(SableFonce)
    ) {
        Box(
            Modifier
                .fillMaxHeight()
                .fillMaxWidth(fraction.coerceIn(0f, 1f))
                .background(BordeauxColor)
        )
        Box(
            Modifier
                .offset(x = maxWidth * reserveFraction.coerceIn(0f, 1f))
                .width(2.dp)
                .fillMaxHeight()
                .background(Color.Black)
        )
    }
}

@Composable
private fun MetricCard(label: String, value: String, sub: String?, modifier: Modifier = Modifier) {
    Card(modifier) {
        Column(Modifier.padding(12.dp)) {
            Text(label, fontSize = 13.sp)
            Text(value, fontSize = 22.sp, fontWeight = FontWeight.Bold)
            if (sub != null) Text(sub, fontSize = 12.sp)
        }
    }
}

@Composable
private fun ConsumerToggle(label: String, rate: Double, running: Boolean, elapsedMs: Long, onClick: () -> Unit) {
    val bg = if (running) BordeauxColor else SableColor
    val fg = if (running) SableColor else TextColor
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick),
        colors = CardDefaults.cardColors(containerColor = bg, contentColor = fg),
        border = BorderStroke(1.dp, BordeauxColor)
    ) {
        Row(Modifier.padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(label, fontSize = 16.sp, fontWeight = FontWeight.SemiBold, color = fg)
                Text(fr("%.2f L/h", rate), fontSize = 12.sp, color = fg)
            }
            Text(
                if (running) "ON · ${formatDuration(elapsedMs)}" else "OFF",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = fg
            )
        }
    }
}

@Composable
private fun TripCard(title: String, d: FuelData, trip: TripData, now: Long, onReset: () -> Unit) {
    val dateFormat = remember { SimpleDateFormat("dd/MM/yy", Locale.FRANCE) }
    Card(Modifier.fillMaxWidth()) {
        Column(Modifier.padding(16.dp)) {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                Text(title, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                Text("  depuis le ${dateFormat.format(Date(trip.startedAt))}", fontSize = 12.sp, modifier = Modifier.weight(1f))
                TextButton(onClick = onReset) { Text("Zéro") }
            }
            TripRow("", "Heures", "Litres", "Moy.", header = true)
            var totalLiters = 0.0
            FuelConsumer.values().forEach { type ->
                val ms = FuelState.tripMs(d, trip, type, now)
                val liters = FuelState.tripLiters(d, trip, type, now)
                totalLiters += liters
                val hours = ms / 3_600_000.0
                TripRow(
                    type.label.substringBefore(" "),
                    formatDuration(ms),
                    fr("%.0f L", liters),
                    if (hours >= 0.05) fr("%.2f L/h", liters / hours) else "—"
                )
            }
            HorizontalDivider(Modifier.padding(vertical = 6.dp), color = BordeauxColor)
            TripRow("Total", "", fr("%.0f L", totalLiters), fr("%.0f €", FuelState.tripCost(d, trip, now)), header = true)
            val engineLiters = FuelState.tripLiters(d, trip, FuelConsumer.ENGINE, now)
            Spacer(Modifier.height(4.dp))
            Text(
                fr("Distance moteur : %.1f nm", trip.distanceNm) +
                    if (trip.distanceNm >= 1.0) fr(" · %.2f L/nm moyen", engineLiters / trip.distanceNm) else "",
                fontSize = 13.sp
            )
        }
    }
}

@Composable
private fun TripRow(a: String, b: String, c: String, e: String, header: Boolean = false) {
    val weight = if (header) FontWeight.SemiBold else FontWeight.Normal
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(a, fontSize = 13.sp, fontWeight = weight, modifier = Modifier.weight(1.2f))
        Text(b, fontSize = 13.sp, fontWeight = weight, modifier = Modifier.weight(1f))
        Text(c, fontSize = 13.sp, fontWeight = weight, modifier = Modifier.weight(0.8f))
        Text(e, fontSize = 13.sp, fontWeight = weight, modifier = Modifier.weight(1f))
    }
}

// -------------------------------------------------------------------------------------------
// Dialogues
// -------------------------------------------------------------------------------------------

@Composable
private fun NumberField(value: String, onChange: (String) -> Unit, label: String, modifier: Modifier = Modifier.fillMaxWidth()) {
    OutlinedTextField(
        value = value,
        onValueChange = { v -> onChange(v.filter { it.isDigit() || it == ',' || it == '.' }) },
        label = { Text(label) },
        singleLine = true,
        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
        modifier = modifier
    )
}

@Composable
private fun FillDialog(
    currentPrice: Double,
    capacityL: Double,
    onDismiss: () -> Unit,
    onConfirm: (liters: Double, price: Double?, full: Boolean) -> Unit
) {
    var liters by remember { mutableStateOf("") }
    var price by remember { mutableStateOf(fr("%.2f", currentPrice)) }
    var full by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Plein") },
        text = {
            Column {
                NumberField(liters, { liters = it; error = null }, "Litres ajoutés")
                Spacer(Modifier.height(8.dp))
                NumberField(price, { price = it }, "Prix au litre (€)")
                Spacer(Modifier.height(8.dp))
                Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.clickable { full = !full }) {
                    Checkbox(checked = full, onCheckedChange = { full = it })
                    Text(fr("Cuves pleines (52 cm, %.0f L)", capacityL), fontSize = 14.sp)
                }
                if (full) Text("Le plein complet sert aussi de mesure : il recale le niveau et affine les débits.", fontSize = 12.sp)
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val l = liters.toDoubleFr()
                if (l == null || l <= 0.0) {
                    error = "Indique les litres ajoutés"
                } else {
                    onConfirm(l, price.toDoubleFr()?.takeIf { it > 0 }, full)
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun DipModeChips(isPige: Boolean, offsetCm: Double, onChange: (Boolean) -> Unit) {
    Row {
        FilterChipLike(fr("Pige +%.0f cm", offsetCm), isPige) { onChange(true) }
        Spacer(Modifier.width(8.dp))
        FilterChipLike("Hauteur réelle", !isPige) { onChange(false) }
    }
}

@Composable
private fun DipDialog(
    s: FuelSettings,
    onDismiss: () -> Unit,
    onConfirm: (port: Double, portPige: Boolean, starboard: Double?, starboardPige: Boolean, probe: Double?) -> Unit
) {
    var port by remember { mutableStateOf("") }
    var portPige by remember { mutableStateOf(true) }
    var starboard by remember { mutableStateOf("") }
    var starboardPige by remember { mutableStateOf(true) }
    var probe by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    val portReal = port.toDoubleFr()?.let { it + if (portPige) s.pigeOffsetCm else 0.0 }
    val starboardReal = starboard.toDoubleFr()?.let { it + if (starboardPige) s.pigeOffsetCm else 0.0 }
    val avg = when {
        portReal != null && starboardReal != null -> (portReal + starboardReal) / 2.0
        else -> portReal
    }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Mesure à la pige") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                NumberField(port, { port = it; error = null }, "Cuve bâbord (cm)")
                DipModeChips(portPige, s.pigeOffsetCm) { portPige = it }
                Spacer(Modifier.height(8.dp))
                NumberField(starboard, { starboard = it }, "Cuve tribord (cm, facultatif)")
                DipModeChips(starboardPige, s.pigeOffsetCm) { starboardPige = it }
                Text("Si le bateau n'est pas droit, mesure les deux cuves : la moyenne donne le vrai niveau.", fontSize = 12.sp)
                Spacer(Modifier.height(8.dp))
                NumberField(probe, { probe = it }, "Lecture sonde tribord (cm, facultatif)")
                Text("Permet d'affiner la zone morte sous le flotteur.", fontSize = 12.sp)
                if (avg != null) {
                    Spacer(Modifier.height(8.dp))
                    Text(fr("Hauteur réelle retenue : %.1f cm → %.0f L", avg, avg * s.litersPerCm), fontWeight = FontWeight.SemiBold)
                }
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val p = port.toDoubleFr()
                val sb = starboard.toDoubleFr()
                when {
                    p == null -> error = "Indique la hauteur côté bâbord"
                    avg == null || avg < 0 || avg > s.tankDepthCm -> error = fr("Hauteur hors de la cuve (0 à %.0f cm)", s.tankDepthCm)
                    starboard.isNotBlank() && sb == null -> error = "Hauteur tribord illisible"
                    else -> onConfirm(p, portPige, sb, starboardPige, probe.toDoubleFr())
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}

@Composable
private fun SettingsDialog(d: FuelData, now: Long, onDismiss: () -> Unit) {
    val s = d.settings
    val rateFields = remember {
        FuelConsumer.values().associateWith { mutableStateOf(fr("%.2f", d.consumers.getValue(it).rateLph)) }
    }
    val hourFields = remember {
        FuelConsumer.values().associateWith { mutableStateOf(fr("%.1f", FuelState.totalMs(d, it, now) / 3_600_000.0)) }
    }
    var price by remember { mutableStateOf(fr("%.2f", s.pricePerLiter)) }
    var threshold by remember { mutableStateOf(fr("%.0f", s.alertThresholdL)) }
    var alertOn by remember { mutableStateOf(s.alertEnabled) }
    var deadZone by remember { mutableStateOf(fr("%.1f", s.deadZoneCm)) }
    var lpcm by remember { mutableStateOf(fr("%.2f", s.litersPerCmPerTank)) }
    var pigeOffset by remember { mutableStateOf(fr("%.1f", s.pigeOffsetCm)) }
    var cruise by remember { mutableStateOf(fr("%.1f", s.cruiseSpeedKn)) }
    var error by remember { mutableStateOf<String?>(null) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Réglages carburant") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState())) {
                Text("Débits (L/h)", fontWeight = FontWeight.Bold)
                Text("Appris automatiquement à chaque pige, modifiables à la main.", fontSize = 12.sp)
                FuelConsumer.values().forEach { type ->
                    val field = rateFields.getValue(type)
                    NumberField(field.value, { field.value = it }, type.label)
                }
                Spacer(Modifier.height(12.dp))
                Text("Horodateurs totaux (heures)", fontWeight = FontWeight.Bold)
                Text("Règle-les une fois sur tes vrais compteurs.", fontSize = 12.sp)
                FuelConsumer.values().forEach { type ->
                    val field = hourFields.getValue(type)
                    NumberField(field.value, { field.value = it }, type.label)
                }
                Spacer(Modifier.height(12.dp))
                Text("Alerte Telegram", fontWeight = FontWeight.Bold)
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = alertOn, onCheckedChange = { alertOn = it })
                    Spacer(Modifier.width(8.dp))
                    Text(if (alertOn) "Activée" else "Désactivée")
                }
                NumberField(threshold, { threshold = it }, "Seuil d'alerte (L)")
                Spacer(Modifier.height(12.dp))
                Text("Cuves et mesures", fontWeight = FontWeight.Bold)
                NumberField(lpcm, { lpcm = it }, "Litres par cm, par cuve")
                NumberField(deadZone, { deadZone = it }, "Zone morte sonde (cm)")
                NumberField(pigeOffset, { pigeOffset = it }, "Correction pige (cm)")
                Spacer(Modifier.height(12.dp))
                Text("Divers", fontWeight = FontWeight.Bold)
                NumberField(price, { price = it }, "Prix du gazole (€/L)")
                NumberField(cruise, { cruise = it }, "Vitesse de croisière 1200 tr/min (nd)")
                error?.let { Text(it, color = MaterialTheme.colorScheme.error, fontSize = 13.sp) }
            }
        },
        confirmButton = {
            TextButton(onClick = {
                val rates = rateFields.mapValues { it.value.value.toDoubleFr() }
                val hours = hourFields.mapValues { it.value.value.toDoubleFr() }
                val newSettings = s.copy(
                    pricePerLiter = price.toDoubleFr() ?: -1.0,
                    alertThresholdL = threshold.toDoubleFr() ?: -1.0,
                    alertEnabled = alertOn,
                    deadZoneCm = deadZone.toDoubleFr() ?: -1.0,
                    litersPerCmPerTank = lpcm.toDoubleFr() ?: -1.0,
                    pigeOffsetCm = pigeOffset.toDoubleFr() ?: -1.0,
                    cruiseSpeedKn = cruise.toDoubleFr() ?: -1.0
                )
                val invalid = rates.any { (type, r) -> r == null || r < type.minRateLph || r > type.maxRateLph } ||
                    hours.values.any { it == null || it < 0 } ||
                    newSettings.pricePerLiter <= 0 || newSettings.alertThresholdL < 0 ||
                    newSettings.deadZoneCm < 0 || newSettings.deadZoneCm > 20 ||
                    newSettings.litersPerCmPerTank <= 0 || newSettings.pigeOffsetCm < 0 ||
                    newSettings.cruiseSpeedKn <= 0
                if (invalid) {
                    error = "Une valeur est vide ou hors plage (débits : moteur 1–12, groupe 0,2–4, Webasto 0,1–2 L/h)"
                } else {
                    FuelState.updateSettings(
                        newSettings,
                        rates.mapValues { it.value!! },
                        hours.mapValues { it.value!! }
                    )
                    onDismiss()
                }
            }) { Text("Enregistrer") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuler") } }
    )
}
