package com.hoppetossa.nmeadash

/**
 * Parseur minimal de trames NMEA0183 pour un dashboard instruments (profondeur, vent, vitesse).
 *
 * Prend en entrée une trame brute du type "$IIDPT,3.5,0.5*7C" (avec ou sans checksum) et renvoie
 * une fonction de mise à jour à appliquer à l'InstrumentData courant, ou null si la trame n'est
 * pas reconnue / pas exploitable.
 *
 * Talkers usuels rencontrés sur un réseau ST60 + AIS : II (Integrated Instrumentation), GP (GPS),
 * AI (AIS), WI (wind instrument)... On ignore volontairement le talker et on se base sur le type
 * de trame (les 3 lettres après le talker).
 */
object NmeaParser {

    fun parse(rawLine: String, current: InstrumentData): InstrumentData? {
        val line = rawLine.trim()
        if (line.isEmpty() || !line.startsWith("$")) return null
        if (!isChecksumValidOrAbsent(line)) return null

        // Retire le checksum ("*hh") s'il existe, puis découpe en champs
        val body = line.substringBefore("*").removePrefix("$")
        val fields = body.split(",")
        if (fields.isEmpty()) return null

        val sentenceType = fields[0].drop(2) // enlève le talker (2 lettres), garde ex: "DPT", "MWV"

        return try {
            when (sentenceType) {
                "DPT" -> parseDpt(fields, current)
                "DBT" -> parseDbt(fields, current)
                "MWV" -> parseMwv(fields, current)
                "VHW" -> parseVhw(fields, current)
                "VTG" -> parseVtg(fields, current)
                "GGA" -> parseGga(fields, current)
                "RMC" -> parseRmc(fields, current)
                else -> null
            }?.copy(lastSentenceAt = System.currentTimeMillis(), lastRawSentence = line)
        } catch (e: Exception) {
            // Trame malformée / champ vide inattendu : on l'ignore silencieusement
            null
        }
    }

    // $--DPT,depth_below_transducer,offset*hh  -> profondeur réelle = champ1 + offset
    private fun parseDpt(f: List<String>, current: InstrumentData): InstrumentData? {
        val depth = f.getOrNull(1)?.toDoubleOrNull() ?: return null
        val offset = f.getOrNull(2)?.toDoubleOrNull() ?: 0.0
        return current.copy(depthMeters = depth + offset)
    }

    // $--DBT,depth_ft,f,depth_m,M,depth_fathoms,F*hh -> on prend le champ en mètres (index 3)
    private fun parseDbt(f: List<String>, current: InstrumentData): InstrumentData? {
        val depthM = f.getOrNull(3)?.toDoubleOrNull() ?: return null
        return current.copy(depthMeters = depthM)
    }

    // $--MWV,angle,reference(R/T),speed,units(N/M/K),status(A/V)*hh
    // reference "R" = vent apparent (relatif), "T" = vent réel (true)
    private fun parseMwv(f: List<String>, current: InstrumentData): InstrumentData? {
        val status = f.getOrNull(5)
        if (status != null && status != "A") return null // donnée invalide côté instrument

        val angle = f.getOrNull(1)?.toDoubleOrNull() ?: return null
        val reference = f.getOrNull(2) // "R" = apparent, "T" = vrai
        // NB: certains multiplexeurs SeaTalk->NMEA0183 (dont le NEA3WiFi avec des ST60)
        // renvoient toujours l'unité "K" dans le champ MWV alors que la valeur d'origine
        // SeaTalk est déjà en dixièmes de noeud. On traite donc la vitesse vent comme
        // toujours exprimée en noeuds, en ignorant l'unité déclarée, pour matcher
        // l'affichage réel du ST60. A réévaluer si un autre multiplexeur/firmware est utilisé.
        val speedKn = f.getOrNull(3)?.toDoubleOrNull() ?: return null

        return if (reference == "T") {
            current.copy(windTrueAngleDeg = angle, windTrueSpeedKn = speedKn)
        } else {
            // "R" ou absent -> on considère apparent par défaut
            current.copy(windApparentAngleDeg = angle, windApparentSpeedKn = speedKn)
        }
    }

    // $--VHW,headingT,T,headingM,M,speedKn,N,speedKmh,K*hh -> vitesse surface (loch)
    private fun parseVhw(f: List<String>, current: InstrumentData): InstrumentData? {
        val speedKn = f.getOrNull(5)?.toDoubleOrNull() ?: return null
        return current.copy(speedThroughWaterKn = speedKn)
    }

    // $--VTG,trackT,T,trackM,M,speedKn,N,speedKmh,K*hh -> vitesse fond (GPS) + route fond (COG)
    private fun parseVtg(f: List<String>, current: InstrumentData): InstrumentData? {
        val speedKn = f.getOrNull(5)?.toDoubleOrNull() ?: return null
        val trackTrue = f.getOrNull(1)?.toDoubleOrNull()
        return current.copy(
            speedOverGroundKn = speedKn,
            courseOverGroundDeg = trackTrue ?: current.courseOverGroundDeg
        )
    }

    // $--GGA,time,lat,N/S,lon,E/W,fixQuality,numSat,hdop,alt,M,geoidSep,M,dgpsAge,dgpsId*hh
    private fun parseGga(f: List<String>, current: InstrumentData): InstrumentData? {
        val fixQuality = f.getOrNull(6)?.toIntOrNull() ?: 0
        if (fixQuality == 0) return null // pas de fix GPS, on ignore

        val latRaw = f.getOrNull(2)?.toDoubleOrNull() ?: return null
        val latDir = f.getOrNull(3) ?: return null
        val lonRaw = f.getOrNull(4)?.toDoubleOrNull() ?: return null
        val lonDir = f.getOrNull(5) ?: return null

        return current.copy(
            latitude = nmeaCoordToDecimal(latRaw, latDir),
            longitude = nmeaCoordToDecimal(lonRaw, lonDir)
        )
    }

    // $--RMC,time,status(A/V),lat,N/S,lon,E/W,speedKn,track,date,magVar,magVarDir,mode*hh
    private fun parseRmc(f: List<String>, current: InstrumentData): InstrumentData? {
        val status = f.getOrNull(2)
        if (status != "A") return null // "V" = données invalides

        val latRaw = f.getOrNull(3)?.toDoubleOrNull() ?: return null
        val latDir = f.getOrNull(4) ?: return null
        val lonRaw = f.getOrNull(5)?.toDoubleOrNull() ?: return null
        val lonDir = f.getOrNull(6) ?: return null
        val speedKn = f.getOrNull(7)?.toDoubleOrNull()
        val trackTrue = f.getOrNull(8)?.toDoubleOrNull()

        return current.copy(
            latitude = nmeaCoordToDecimal(latRaw, latDir),
            longitude = nmeaCoordToDecimal(lonRaw, lonDir),
            speedOverGroundKn = speedKn ?: current.speedOverGroundKn,
            courseOverGroundDeg = trackTrue ?: current.courseOverGroundDeg
        )
    }

    /**
     * Convertit une coordonnée au format NMEA (ddmm.mmmm pour la latitude,
     * dddmm.mmmm pour la longitude) en degrés décimaux signés (+ N/E, - S/W).
     */
    private fun nmeaCoordToDecimal(raw: Double, direction: String): Double {
        val degrees = kotlin.math.floor(raw / 100.0)
        val minutes = raw - degrees * 100.0
        var decimal = degrees + minutes / 60.0
        if (direction == "S" || direction == "W") decimal = -decimal
        return decimal
    }

    /**
     * Vérifie le checksum XOR si présent (format *hh en fin de trame).
     * Si absent, on laisse passer la trame (certains flux le tronquent).
     */
    private fun isChecksumValidOrAbsent(line: String): Boolean {
        val starIndex = line.indexOf('*')
        if (starIndex == -1 || starIndex + 3 > line.length) return true // pas de checksum, on tente quand même

        val body = line.substring(1, starIndex) // sans le '$' initial
        val expected = line.substring(starIndex + 1, starIndex + 3).uppercase()

        var checksum = 0
        for (c in body) checksum = checksum xor c.code

        val computed = "%02X".format(checksum)
        return computed == expected
    }
}
