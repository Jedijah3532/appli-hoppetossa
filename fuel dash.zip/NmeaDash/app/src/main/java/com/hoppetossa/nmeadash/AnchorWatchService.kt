package com.hoppetossa.nmeadash

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.media.AudioAttributes
import android.media.MediaPlayer
import android.media.RingtoneManager
import android.os.Build
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import androidx.core.app.NotificationCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch
import kotlinx.coroutines.isActive
import kotlinx.coroutines.delay
import kotlinx.coroutines.Dispatchers

/**
 * Service en avant-plan (foreground service) : tant qu'il tourne, l'appli continue de recevoir
 * la position NMEA et de surveiller la distance par rapport au point d'ancre, même écran éteint
 * ou appli en arrière-plan. Déclenche une alarme sonore + vibration continue en cas de dérapage.
 */
class AnchorWatchService : Service() {

    companion object {
        const val CHANNEL_ID = "anchor_watch_channel"
        const val NOTIFICATION_ID = 1001
        const val ACTION_STOP_ALARM = "com.hoppetossa.nmeadash.STOP_ALARM"
        const val ACTION_STOP_SERVICE = "com.hoppetossa.nmeadash.STOP_SERVICE"
    }

    private val serviceScope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var monitorJob: Job? = null
    private var commandPollingJob: Job? = null
    private var mediaPlayer: MediaPlayer? = null
    private var vibrator: Vibrator? = null
    private var lastRecordedAt: Long = 0L
    private var telegramUpdateOffset: Long? = null

    override fun onCreate() {
        super.onCreate()
        TelegramSettings.init(applicationContext)
        FuelState.init(applicationContext)
        createNotificationChannel()
        vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            (getSystemService(VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
        } else {
            @Suppress("DEPRECATION")
            getSystemService(VIBRATOR_SERVICE) as Vibrator
        }
    }

    private fun sendTelegramAlert(distanceMeters: Double, radiusMeters: Double, lat: Double, lon: Double) {
        if (!TelegramSettings.isConfigured()) return
        val mapsLink = "https://maps.google.com/?q=$lat,$lon"
        val message = "⚠️ ALARME MOUILLAGE — Hoppetossa dérape !\n" +
            "Distance ancre : %.0f m (rayon %.0f m)\n".format(distanceMeters, radiusMeters) +
            "Position : $mapsLink"
        serviceScope.launch {
            TelegramNotifier.sendMessage(
                TelegramSettings.botToken.value,
                TelegramSettings.chatId.value,
                message
            )
        }
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_STOP_ALARM -> {
                stopAlarmSound()
                AnchorState.setAlarming(false)
                updateNotification()
                return START_STICKY
            }
            ACTION_STOP_SERVICE -> {
                stopWatching()
                stopSelf()
                return START_NOT_STICKY
            }
        }

        startForeground(NOTIFICATION_ID, buildNotification())
        startWatching()
        return START_STICKY
    }

    private fun startWatching() {
        AnchorState.setWatching(true)
        lastRecordedAt = System.currentTimeMillis()

        if (!NmeaRepository.isActive()) {
            NmeaRepository.connect()
        }

        monitorJob?.cancel()
        monitorJob = serviceScope.launch {
            PositionRepository.currentFix.collect { fix ->
                val anchor = AnchorState.anchor.value ?: return@collect
                if (fix == null) return@collect
                val lat = fix.latitude
                val lon = fix.longitude

                val distance = haversineMeters(anchor.latitude, anchor.longitude, lat, lon)
                AnchorState.updateDistance(distance)

                val radius = AnchorState.securityRadiusMeters.value
                if (distance > radius) {
                    if (!AnchorState.isAlarming.value) {
                        AnchorState.setAlarming(true)
                        startAlarmSound()
                        sendTelegramAlert(distance, radius, lat, lon)
                    }
                } else {
                    if (AnchorState.isAlarming.value) {
                        AnchorState.setAlarming(false)
                        stopAlarmSound()
                    }
                }

                val now = System.currentTimeMillis()
                val intervalMillis = AnchorState.recordingInterval.value.millis
                if (now - lastRecordedAt >= intervalMillis) {
                    lastRecordedAt = now
                    AnchorState.addTrackPoint(TrackPoint(lat, lon, now))
                }

                updateNotification()
            }
        }

        startCommandPolling()
    }

    /**
     * Boucle de "long polling" : interroge l'API Telegram en continu (la requête reste ouverte
     * jusqu'à 25s s'il n'y a rien de nouveau, pour limiter le nombre de requêtes) et répond aux
     * commandes reçues (/position, /profondeur, /vent, /vitesse, /cap, /mouillage, /aide).
     */
    private fun startCommandPolling() {
        commandPollingJob?.cancel()
        if (!TelegramSettings.isConfigured()) return

        commandPollingJob = serviceScope.launch {
            while (kotlin.coroutines.coroutineContext.isActive) {
                try {
                    val token = TelegramSettings.botToken.value
                    val configuredChatId = TelegramSettings.chatId.value
                    val updates = TelegramNotifier.getUpdates(token, telegramUpdateOffset)

                    for (update in updates) {
                        telegramUpdateOffset = update.updateId + 1
                        if (update.chatId != configuredChatId) continue // ignore les autres expéditeurs
                        val reply = buildReplyForCommand(update.text)
                        if (reply != null) {
                            TelegramNotifier.sendMessage(token, configuredChatId, reply)
                        }
                    }
                } catch (e: Exception) {
                    android.util.Log.e("AnchorWatchService", "Erreur polling Telegram", e)
                    kotlinx.coroutines.delay(5_000)
                }
            }
        }
    }

    private fun buildReplyForCommand(rawText: String): String? {
        val command = rawText.trim().lowercase().removePrefix("/")
        val instrument = NmeaRepository.data.value
        val fix = PositionRepository.currentFix.value

        return when {
            command.startsWith("position") -> {
                if (fix != null) {
                    val source = if (fix.source == PositionSource.NMEA) "NMEA" else "GPS téléphone"
                    "📍 Position ($source) : ${formatLatLon(fix.latitude, fix.longitude)}\n" +
                        "https://maps.google.com/?q=${fix.latitude},${fix.longitude}"
                } else "Pas de position disponible pour l'instant."
            }
            command.startsWith("profondeur") -> {
                instrument.depthMeters?.let { "🌊 Profondeur : %.1f m".format(it) }
                    ?: "Pas de donnée de profondeur disponible."
            }
            command.startsWith("vent") -> {
                val apparent = if (instrument.windApparentAngleDeg != null && instrument.windApparentSpeedKn != null)
                    "%.0f° / %.1f kn".format(instrument.windApparentAngleDeg, instrument.windApparentSpeedKn)
                else "—"
                val reel = if (instrument.windTrueAngleDeg != null && instrument.windTrueSpeedKn != null)
                    "%.0f° / %.1f kn".format(instrument.windTrueAngleDeg, instrument.windTrueSpeedKn)
                else "—"
                "💨 Vent apparent : $apparent\nVent réel : $reel"
            }
            command.startsWith("vitesse") -> {
                val surface = instrument.speedThroughWaterKn?.let { "%.1f kn".format(it) } ?: "—"
                val fond = instrument.speedOverGroundKn?.let { "%.1f kn".format(it) } ?: "—"
                "⛵ Vitesse surface : $surface\nVitesse fond (GPS) : $fond"
            }
            command.startsWith("cap") -> {
                instrument.courseOverGroundDeg?.let { "🧭 Cap (COG) : %.0f°".format(it) }
                    ?: "Pas de cap disponible (fiable seulement en mouvement)."
            }
            command.startsWith("mouillage") || command.startsWith("statut") -> {
                val anchor = AnchorState.anchor.value
                if (anchor == null) {
                    "⚓ Pas de mouillage en cours."
                } else {
                    val distance = AnchorState.currentDistanceMeters.value
                    val radius = AnchorState.securityRadiusMeters.value
                    val alarming = AnchorState.isAlarming.value
                    "⚓ Ancre : ${formatLatLon(anchor.latitude, anchor.longitude)}\n" +
                        "Distance actuelle : ${distance?.let { "%.0f m".format(it) } ?: "—"} (rayon %.0f m)\n".format(radius) +
                        "Alarme : ${if (alarming) "⚠️ ACTIVE" else "OK"}"
                }
            }
            command.startsWith("gazole") || command.startsWith("fuel") -> {
                "⛽ " + FuelState.telegramSummary()
            }
            command.startsWith("aide") || command.startsWith("help") || command.startsWith("start") -> {
                "Commandes disponibles :\n" +
                    "/position — position GPS actuelle\n" +
                    "/profondeur — profondeur sondeur\n" +
                    "/vent — vent réel et apparent\n" +
                    "/vitesse — vitesse surface et fond\n" +
                    "/cap — cap/route (COG)\n" +
                    "/mouillage — statut du mouillage en cours\n" +
                    "/gazole — niveau et autonomie gazole"
            }
            else -> null
        }
    }

    private fun stopWatching() {
        monitorJob?.cancel()
        monitorJob = null
        commandPollingJob?.cancel()
        commandPollingJob = null
        stopAlarmSound()
        AnchorState.setWatching(false)
    }

    private fun startAlarmSound() {
        if (mediaPlayer?.isPlaying == true) return
        try {
            val alarmUri = RingtoneManager.getActualDefaultRingtoneUri(this, RingtoneManager.TYPE_ALARM)
                ?: RingtoneManager.getDefaultUri(RingtoneManager.TYPE_NOTIFICATION)
            mediaPlayer = MediaPlayer().apply {
                setAudioAttributes(
                    AudioAttributes.Builder()
                        .setUsage(AudioAttributes.USAGE_ALARM)
                        .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                        .build()
                )
                setDataSource(this@AnchorWatchService, alarmUri)
                isLooping = true
                prepare()
                start()
            }
        } catch (e: Exception) {
            android.util.Log.e("AnchorWatchService", "Impossible de lancer le son d'alarme", e)
        }

        val pattern = longArrayOf(0, 800, 400, 800, 400)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            vibrator?.vibrate(VibrationEffect.createWaveform(pattern, 0))
        } else {
            @Suppress("DEPRECATION")
            vibrator?.vibrate(pattern, 0)
        }
    }

    private fun stopAlarmSound() {
        mediaPlayer?.let {
            if (it.isPlaying) it.stop()
            it.release()
        }
        mediaPlayer = null
        vibrator?.cancel()
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(
            CHANNEL_ID,
            "Alarme de mouillage",
            NotificationManager.IMPORTANCE_HIGH
        ).apply {
            description = "Surveillance de la position au mouillage"
            enableVibration(true)
        }
        val manager = getSystemService(NotificationManager::class.java)
        manager.createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val distance = AnchorState.currentDistanceMeters.value
        val radius = AnchorState.securityRadiusMeters.value
        val alarming = AnchorState.isAlarming.value

        val contentText = if (distance != null) {
            "Distance ancre : %.0f m / rayon %.0f m".format(distance, radius)
        } else {
            "En attente de position GPS…"
        }

        val stopAlarmIntent = Intent(this, AnchorWatchService::class.java).apply { action = ACTION_STOP_ALARM }
        val stopAlarmPending = PendingIntent.getService(
            this, 0, stopAlarmIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val stopServiceIntent = Intent(this, AnchorWatchService::class.java).apply { action = ACTION_STOP_SERVICE }
        val stopServicePending = PendingIntent.getService(
            this, 1, stopServiceIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val builder = NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_compass)
            .setContentTitle(if (alarming) "⚠ ALARME MOUILLAGE — dérapage !" else "Surveillance mouillage active")
            .setContentText(contentText)
            .setOngoing(true)
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .addAction(0, "Arrêter l'alarme", stopAlarmPending)
            .addAction(0, "Arrêter la surveillance", stopServicePending)

        return builder.build()
    }

    private fun updateNotification() {
        val manager = getSystemService(NotificationManager::class.java)
        manager.notify(NOTIFICATION_ID, buildNotification())
    }

    override fun onDestroy() {
        super.onDestroy()
        stopWatching()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
