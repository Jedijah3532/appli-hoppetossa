package com.hoppetossa.nmeadash

import android.content.Intent
import android.webkit.WebView
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Anchor
import androidx.compose.material.icons.filled.Map
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.window.Dialog
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.cos
import kotlin.math.max
import kotlin.math.sin

@Composable
fun AnchorScreen(onBack: () -> Unit) {
    val context = LocalContext.current
    val instrument by NmeaRepository.data.collectAsState()
    val connectionState by NmeaRepository.connectionState.collectAsState()
    val positionFix by PositionRepository.currentFix.collectAsState()
    val anchor by AnchorState.anchor.collectAsState()
    val radius by AnchorState.securityRadiusMeters.collectAsState()
    val condition by AnchorState.scopeCondition.collectAsState()
    val recordingInterval by AnchorState.recordingInterval.collectAsState()
    val track by AnchorState.track.collectAsState()
    val isWatching by AnchorState.isWatching.collectAsState()
    val isAlarming by AnchorState.isAlarming.collectAsState()
    val distance by AnchorState.currentDistanceMeters.collectAsState()

    var showOnlineMap by remember { mutableStateOf(false) }
    var showReleaseConfirm by remember { mutableStateOf(false) }
    var selectedHistoryEntry by remember { mutableStateOf<AnchorHistoryEntry?>(null) }
    var showHistoryOverview by remember { mutableStateOf(false) }
    var fixMode by remember { mutableStateOf(AnchorFixMode.GPS) }

    LaunchedEffect(Unit) {
        AnchorHistory.init(context)
        TelegramSettings.init(context)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp)
    ) {
        // En-tête avec retour + titre
        Row(verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) {
                Icon(Icons.Filled.ArrowBack, contentDescription = "Retour")
            }
            Icon(Icons.Filled.Anchor, contentDescription = null, modifier = Modifier.padding(horizontal = 4.dp))
            Text("Alarme de mouillage", fontSize = 20.sp, fontWeight = FontWeight.Bold)
        }

        Spacer(Modifier.height(12.dp))

        // Cartouche vent toujours visible
        WindCartouche(instrument)

        Spacer(Modifier.height(16.dp))

        if (isAlarming) {
            AlarmBanner(distance, radius) {
                context.startService(
                    Intent(context, AnchorWatchService::class.java).apply {
                        action = AnchorWatchService.ACTION_STOP_ALARM
                    }
                )
            }
            Spacer(Modifier.height(16.dp))
        }

        if (anchor == null) {
            val phoneLocation by PositionRepository.phoneLocation.collectAsState()
            SetAnchorCard(
                depth = instrument.depthMeters,
                fixMode = fixMode,
                onFixModeChange = { fixMode = it },
                courseOverGround = instrument.courseOverGroundDeg,
                nmeaConnected = connectionState == ConnectionState.CONNECTED,
                phoneHasPosition = phoneLocation != null,
                nmeaHasPosition = instrument.latitude != null && instrument.longitude != null
            ) {
                val basePosition = when (fixMode) {
                    AnchorFixMode.PROUE, AnchorFixMode.COCKPIT -> phoneLocation?.let { it.latitude to it.longitude }
                    AnchorFixMode.GPS -> instrument.latitude?.let { lat ->
                        instrument.longitude?.let { lon -> lat to lon }
                    }
                }

                basePosition?.let { (lat, lon) ->
                    val cog = instrument.courseOverGroundDeg
                    val (finalLat, finalLon) = if (cog != null && fixMode.offsetMeters > 0.0) {
                        projectPosition(lat, lon, cog, fixMode.offsetMeters)
                    } else {
                        lat to lon // pas de cap dispo : on garde la position brute, sans correction
                    }
                    AnchorState.setAnchor(
                        AnchorPoint(
                            latitude = finalLat,
                            longitude = finalLon,
                            depthAtAnchorMeters = instrument.depthMeters,
                            setAt = System.currentTimeMillis()
                        )
                    )
                }
            }
        } else {
            AnchorInfoCard(
                anchor = anchor!!,
                distance = distance,
                boatPosition = positionFix,
                onReleaseAnchor = { showReleaseConfirm = true }
            )

            Spacer(Modifier.height(16.dp))

            SecurityRadiusCard(
                depth = anchor!!.depthAtAnchorMeters ?: instrument.depthMeters,
                radius = radius,
                condition = condition,
                onRadiusChange = { AnchorState.setSecurityRadius(it) },
                onConditionChange = { AnchorState.setScopeCondition(it) }
            )

            Spacer(Modifier.height(16.dp))

            RecordingIntervalCard(
                selected = recordingInterval,
                onSelect = { AnchorState.setRecordingInterval(it) }
            )

            Spacer(Modifier.height(16.dp))

            Button(
                onClick = {
                    if (isWatching) {
                        context.startService(
                            Intent(context, AnchorWatchService::class.java).apply {
                                action = AnchorWatchService.ACTION_STOP_SERVICE
                            }
                        )
                    } else {
                        context.startForegroundService(Intent(context, AnchorWatchService::class.java))
                    }
                },
                modifier = Modifier.fillMaxWidth(),
                colors = if (isWatching)
                    ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.error)
                else ButtonDefaults.buttonColors()
            ) {
                Text(if (isWatching) "Arrêter la surveillance" else "Démarrer la surveillance")
            }

            Spacer(Modifier.height(16.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Visualisation", fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { showOnlineMap = !showOnlineMap }) {
                    Icon(Icons.Filled.Map, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text(if (showOnlineMap) "Schéma hors-ligne" else "Carte en ligne")
                }
            }

            Spacer(Modifier.height(8.dp))

            if (showOnlineMap) {
                OnlineMapView(
                    anchor = anchor,
                    boatLat = positionFix?.latitude,
                    boatLon = positionFix?.longitude,
                    track = track,
                    radiusMeters = radius
                )
            } else {
                OfflineSchematicView(
                    anchor = anchor,
                    boatLat = positionFix?.latitude,
                    boatLon = positionFix?.longitude,
                    track = track,
                    radiusMeters = radius
                )
            }
        }

        val history by AnchorHistory.entries.collectAsState()
        if (history.isNotEmpty()) {
            Spacer(Modifier.height(16.dp))
            AnchorHistoryCard(
                history,
                onEntryClick = { selectedHistoryEntry = it },
                onViewAllClick = { showHistoryOverview = true }
            )
        }

        Spacer(Modifier.height(16.dp))
        TelegramSettingsCard(context)
    }

    if (showReleaseConfirm) {
        AlertDialog(
            onDismissRequest = { showReleaseConfirm = false },
            title = { Text("Relever l'ancre ?") },
            text = { Text("Ça va arrêter la surveillance et l'alarme de mouillage. Le point sera gardé dans l'historique.") },
            confirmButton = {
                TextButton(onClick = {
                    anchor?.let { a ->
                        AnchorHistory.addEntry(
                            context,
                            AnchorHistoryEntry(
                                latitude = a.latitude,
                                longitude = a.longitude,
                                depthAtAnchorMeters = a.depthAtAnchorMeters,
                                setAt = a.setAt,
                                releasedAt = System.currentTimeMillis(),
                                radiusMeters = radius,
                                track = track
                            )
                        )
                    }
                    context.startService(
                        Intent(context, AnchorWatchService::class.java).apply {
                            action = AnchorWatchService.ACTION_STOP_SERVICE
                        }
                    )
                    AnchorState.clearAnchor()
                    showReleaseConfirm = false
                }) {
                    Text("Relever l'ancre")
                }
            },
            dismissButton = {
                TextButton(onClick = { showReleaseConfirm = false }) {
                    Text("Annuler")
                }
            }
        )
    }

    selectedHistoryEntry?.let { entry ->
        Dialog(onDismissRequest = { selectedHistoryEntry = null }) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "Mouillage du ${SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE).format(Date(entry.setAt))}",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(8.dp))
                    OnlineMapView(
                        anchor = AnchorPoint(entry.latitude, entry.longitude, entry.depthAtAnchorMeters, entry.setAt),
                        boatLat = null,
                        boatLon = null,
                        track = entry.track,
                        radiusMeters = entry.radiusMeters
                    )
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { selectedHistoryEntry = null }, modifier = Modifier.fillMaxWidth()) {
                        Text("Fermer")
                    }
                }
            }
        }
    }

    if (showHistoryOverview) {
        val history by AnchorHistory.entries.collectAsState()
        Dialog(onDismissRequest = { showHistoryOverview = false }) {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "Tous les mouillages (${history.size})",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.SemiBold
                    )
                    Spacer(Modifier.height(8.dp))
                    HistoryOverviewMapView(history)
                    Spacer(Modifier.height(8.dp))
                    Button(onClick = { showHistoryOverview = false }, modifier = Modifier.fillMaxWidth()) {
                        Text("Fermer")
                    }
                }
            }
        }
    }
}

@Composable
fun AnchorHistoryCard(
    history: List<AnchorHistoryEntry>,
    onEntryClick: (AnchorHistoryEntry) -> Unit,
    onViewAllClick: () -> Unit
) {
    val dateFormat = remember { SimpleDateFormat("dd/MM HH:mm", Locale.FRANCE) }
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Historique des mouillages", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = onViewAllClick) {
                    Icon(Icons.Filled.Map, contentDescription = null)
                    Spacer(Modifier.width(4.dp))
                    Text("Voir tout")
                }
            }
            Text(
                "Appuie sur un mouillage pour le voir sur une carte (nécessite internet)",
                fontSize = 11.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(Modifier.height(8.dp))
            history.take(10).forEach { entry ->
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { onEntryClick(entry) }
                        .padding(vertical = 6.dp)
                ) {
                    Text(
                        formatLatLon(entry.latitude, entry.longitude),
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium
                    )
                    val depthText = entry.depthAtAnchorMeters?.let { " · %.1f m de fond".format(it) } ?: ""
                    Text(
                        "Mouillé ${dateFormat.format(Date(entry.setAt))} → relevé ${dateFormat.format(Date(entry.releasedAt))}$depthText",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
                Divider()
            }
            if (history.size > 10) {
                Spacer(Modifier.height(4.dp))
                Text(
                    "+ ${history.size - 10} mouillage(s) plus ancien(s)",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
    }
}

@Composable
fun TelegramSettingsCard(context: android.content.Context) {
    val savedToken by TelegramSettings.botToken.collectAsState()
    val savedChatId by TelegramSettings.chatId.collectAsState()
    val savedEnabled by TelegramSettings.enabled.collectAsState()

    var token by remember(savedToken) { mutableStateOf(savedToken) }
    var chatId by remember(savedChatId) { mutableStateOf(savedChatId) }
    var enabled by remember(savedEnabled) { mutableStateOf(savedEnabled) }
    var showInstructions by remember { mutableStateOf(false) }
    var testResult by remember { mutableStateOf<String?>(null) }
    val scope = rememberCoroutineScope()

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text("Alerte à distance (Telegram)", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                TextButton(onClick = { showInstructions = !showInstructions }) {
                    Text(if (showInstructions) "Masquer l'aide" else "Comment faire ?")
                }
            }

            if (showInstructions) {
                Spacer(Modifier.height(8.dp))
                Text(
                    "1. Dans Telegram, cherche \"@BotFather\", envoie /newbot et suis les instructions " +
                        "(choisis un nom). Il te donne un jeton (token) du style \"123456:ABC-def...\".\n" +
                        "2. Cherche \"@userinfobot\" dans Telegram et envoie-lui /start : il te donne ton " +
                        "identifiant de chat (un nombre).\n" +
                        "3. Envoie un premier message à TON bot (cherche-le par le nom que tu lui as donné) " +
                        "pour l'\"activer\" — sinon il ne peut pas t'écrire en premier.\n" +
                        "4. Colle le jeton et l'identifiant ci-dessous, active, et teste.",
                    fontSize = 12.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }

            Spacer(Modifier.height(12.dp))
            OutlinedTextField(
                value = token,
                onValueChange = { token = it },
                label = { Text("Jeton du bot (token)") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            OutlinedTextField(
                value = chatId,
                onValueChange = { chatId = it },
                label = { Text("Identifiant de chat") },
                modifier = Modifier.fillMaxWidth()
            )
            Spacer(Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Text("Activer l'alerte à distance", fontSize = 14.sp)
                Switch(checked = enabled, onCheckedChange = { enabled = it })
            }

            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                Button(onClick = {
                    TelegramSettings.update(context, token, chatId, enabled)
                    testResult = "Enregistré."
                }) {
                    Text("Enregistrer")
                }
                OutlinedButton(
                    onClick = {
                        TelegramSettings.update(context, token, chatId, enabled)
                        scope.launch {
                            testResult = "Envoi..."
                            val ok = TelegramNotifier.sendMessage(
                                token, chatId,
                                "✅ Test Hoppetossa NMEA Dash — si tu reçois ce message, tout fonctionne !"
                            )
                            testResult = if (ok) "Message de test envoyé !" else "Échec — vérifie le jeton/l'identifiant."
                        }
                    },
                    enabled = token.isNotBlank() && chatId.isNotBlank()
                ) {
                    Text("Tester")
                }
            }

            testResult?.let {
                Spacer(Modifier.height(8.dp))
                Text(it, fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
fun WindCartouche(instrument: InstrumentData) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            horizontalArrangement = Arrangement.Center
        ) {
            val angle = instrument.windApparentAngleDeg
            val speed = instrument.windApparentSpeedKn
            Text(
                text = if (angle != null && speed != null)
                    "Vent : %.0f kn / %.0f°".format(speed, angle)
                else "Vent : —",
                fontSize = 16.sp,
                fontWeight = FontWeight.Medium
            )
        }
    }
}

@Composable
fun AlarmBanner(distance: Double?, radius: Double, onStopAlarm: () -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.error)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(
                "⚠ ALARME — le bateau dérape !",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold
            )
            if (distance != null) {
                Text("Distance ancre : %.0f m (rayon : %.0f m)".format(distance, radius))
            }
            Spacer(Modifier.height(8.dp))
            Button(onClick = onStopAlarm) {
                Text("Arrêter l'alarme")
            }
        }
    }
}

@Composable
fun SetAnchorCard(
    depth: Double?,
    fixMode: AnchorFixMode,
    onFixModeChange: (AnchorFixMode) -> Unit,
    courseOverGround: Double?,
    nmeaConnected: Boolean,
    phoneHasPosition: Boolean,
    nmeaHasPosition: Boolean,
    onSetAnchor: () -> Unit
) {
    val sourceAvailable = when (fixMode) {
        AnchorFixMode.PROUE, AnchorFixMode.COCKPIT -> phoneHasPosition
        AnchorFixMode.GPS -> nmeaConnected && nmeaHasPosition
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(
            modifier = Modifier.padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(
                Icons.Filled.Anchor,
                contentDescription = null,
                modifier = Modifier.size(48.dp)
            )
            Spacer(Modifier.height(8.dp))

            Text("D'où mouilles-tu ?", fontSize = 14.sp, fontWeight = FontWeight.Medium)
            Spacer(Modifier.height(4.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                AnchorFixMode.entries.forEach { mode ->
                    FilterChipLike(label = mode.label, selected = fixMode == mode) { onFixModeChange(mode) }
                }
            }
            Spacer(Modifier.height(4.dp))
            Text(
                when (fixMode) {
                    AnchorFixMode.PROUE -> "Position GPS du téléphone, sans correction (tu es à l'avant)."
                    AnchorFixMode.GPS -> "Position de l'antenne NMEA, corrigée de ${GPS_ANTENNA_OFFSET_METERS.toInt()} m vers l'avant."
                    AnchorFixMode.COCKPIT -> "Position GPS du téléphone (au cockpit), corrigée de ${COCKPIT_OFFSET_METERS.toInt()} m vers l'avant."
                },
                fontSize = 12.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            if (fixMode.offsetMeters > 0.0) {
                Spacer(Modifier.height(4.dp))
                Text(
                    if (courseOverGround != null) "Cap actuel (COG) : %.0f°".format(courseOverGround)
                    else "⚠ Pas de cap disponible — la position sera utilisée sans correction",
                    fontSize = 12.sp,
                    color = if (courseOverGround != null) MaterialTheme.colorScheme.onSurfaceVariant
                    else MaterialTheme.colorScheme.error
                )
            }

            Spacer(Modifier.height(8.dp))
            Text(
                if (sourceAvailable) "Prêt à mouiller — appuie une fois l'ancre posée"
                else "En attente de position (${if (fixMode == AnchorFixMode.GPS) "réseau NMEA" else "GPS téléphone"})…",
                fontSize = 14.sp
            )
            if (depth != null) {
                Text("Profondeur actuelle : %.1f m".format(depth), fontSize = 13.sp)
            }
            Spacer(Modifier.height(12.dp))
            Button(
                onClick = onSetAnchor,
                enabled = sourceAvailable,
                modifier = Modifier.fillMaxWidth()
            ) {
                Text("Mouiller ici")
            }
        }
    }
}

@Composable
fun AnchorInfoCard(anchor: AnchorPoint, distance: Double?, boatPosition: PositionFix?, onReleaseAnchor: () -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Point d'ancre", fontSize = 13.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Text(formatLatLon(anchor.latitude, anchor.longitude), fontSize = 16.sp, fontWeight = FontWeight.SemiBold)
                }
                TextButton(onClick = onReleaseAnchor) {
                    Text("Relever l'ancre")
                }
            }
            if (distance != null) {
                Spacer(Modifier.height(8.dp))
                val bearing = boatPosition?.let {
                    bearingDegrees(it.latitude, it.longitude, anchor.latitude, anchor.longitude)
                }
                Text(
                    if (bearing != null)
                        "Distance actuelle : %.0f m — Direction de l'ancre : %.0f°".format(distance, bearing)
                    else "Distance actuelle : %.0f m".format(distance),
                    fontSize = 15.sp
                )
            }
        }
    }
}

@Composable
fun SecurityRadiusCard(
    depth: Double?,
    radius: Double,
    condition: ScopeCondition,
    onRadiusChange: (Double) -> Unit,
    onConditionChange: (ScopeCondition) -> Unit
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Rayon de sécurité", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))

            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                ScopeCondition.entries.forEach { c ->
                    FilterChipLike(
                        label = "${c.label} (${c.ratio}:1)",
                        selected = condition == c
                    ) { onConditionChange(c) }
                }
            }

            Spacer(Modifier.height(12.dp))

            val chainLength = depth?.let { suggestedChainLength(it, condition.ratio) }
            val suggestedRadius = if (depth != null && chainLength != null)
                suggestedSecurityRadius(chainLength, depth) else null

            Text(
                if (chainLength != null)
                    "Chaîne suggérée : %.0f m (pour %.1f m de fond, ratio %d:1)".format(
                        chainLength, depth ?: 0.0, condition.ratio
                    )
                else "Profondeur inconnue — branche l'instrument sondeur pour une suggestion",
                fontSize = 13.sp,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )

            Spacer(Modifier.height(12.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("Rayon : ", fontSize = 14.sp)
                Text("%.0f m".format(radius), fontWeight = FontWeight.Bold, fontSize = 16.sp)
            }
            Slider(
                value = radius.toFloat(),
                onValueChange = { onRadiusChange(it.toDouble()) },
                valueRange = 5f..200f,
                steps = 38
            )

            if (suggestedRadius != null) {
                TextButton(onClick = { onRadiusChange(suggestedRadius) }) {
                    Text("Utiliser le rayon suggéré (%.0f m)".format(suggestedRadius))
                }
            }
        }
    }
}

@Composable
fun RecordingIntervalCard(selected: RecordingInterval, onSelect: (RecordingInterval) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text("Enregistrement de la trace GPS", fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                RecordingInterval.entries.forEach { interval ->
                    FilterChipLike(label = interval.label, selected = selected == interval) {
                        onSelect(interval)
                    }
                }
            }
        }
    }
}

@Composable
fun OfflineSchematicView(
    anchor: AnchorPoint?,
    boatLat: Double?,
    boatLon: Double?,
    track: List<TrackPoint>,
    radiusMeters: Double
) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Box(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp)
                .padding(8.dp)
        ) {
            Canvas(modifier = Modifier.fillMaxSize()) {
                if (anchor == null) return@Canvas

                val distances = mutableListOf(radiusMeters * 1.2)
                if (boatLat != null && boatLon != null) {
                    distances.add(haversineMeters(anchor.latitude, anchor.longitude, boatLat, boatLon) * 1.2)
                }
                track.forEach { p ->
                    distances.add(haversineMeters(anchor.latitude, anchor.longitude, p.latitude, p.longitude) * 1.2)
                }
                val maxDistance = max(distances.max(), 10.0)

                val centerX = size.width / 2
                val centerY = size.height / 2
                val pixelRadius = (kotlin.math.min(size.width, size.height) / 2) * 0.9f

                fun toOffset(lat: Double, lon: Double): Offset {
                    val dist = haversineMeters(anchor.latitude, anchor.longitude, lat, lon)
                    val bearing = Math.toRadians(bearingDegrees(anchor.latitude, anchor.longitude, lat, lon))
                    val scale = (pixelRadius / maxDistance).toFloat()
                    val x = centerX + (dist * sin(bearing)).toFloat() * scale
                    val y = centerY - (dist * cos(bearing)).toFloat() * scale
                    return Offset(x, y)
                }

                // Cercle de sécurité
                val securityPixelRadius = (radiusMeters / maxDistance).toFloat() * pixelRadius
                drawCircle(
                    color = Color(0xFF6D1F2A),
                    radius = securityPixelRadius,
                    center = Offset(centerX, centerY),
                    style = Stroke(width = 3f)
                )

                // Trace GPS
                if (track.size > 1) {
                    val path = androidx.compose.ui.graphics.Path()
                    track.forEachIndexed { index, p ->
                        val off = toOffset(p.latitude, p.longitude)
                        if (index == 0) path.moveTo(off.x, off.y) else path.lineTo(off.x, off.y)
                    }
                    drawPath(path, color = Color(0xFF888888), style = Stroke(width = 2f))
                }
                track.forEach { p ->
                    drawCircle(Color(0xFF888888), radius = 4f, center = toOffset(p.latitude, p.longitude))
                }

                // Point d'ancre (centre)
                drawCircle(Color.Black, radius = 8f, center = Offset(centerX, centerY))

                // Position bateau actuelle
                if (boatLat != null && boatLon != null) {
                    val boatOffset = toOffset(boatLat, boatLon)
                    drawCircle(Color(0xFF1B5E20), radius = 10f, center = boatOffset)
                }
            }
            Text(
                "Nord ↑",
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(4.dp),
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun OnlineMapView(
    anchor: AnchorPoint?,
    boatLat: Double?,
    boatLon: Double?,
    track: List<TrackPoint>,
    radiusMeters: Double
) {
    if (anchor == null) return

    val webViewRef = remember { mutableStateOf<WebView?>(null) }

    // La page (carte, ancre, cercle, tuiles) n'est chargée qu'une fois par mouillage/rayon/trace :
    // on ne veut PAS la recharger à chaque tick de position, sinon ça re-télécharge tuiles + JS en
    // boucle (lourd en data, et certains fournisseurs de tuiles bloquent ce genre d'usage répété).
    val trackJs = remember(track.size) { track.joinToString(",") { "[${it.latitude},${it.longitude}]" } }

    val html = remember(anchor, radiusMeters, trackJs) {
        """
        <!DOCTYPE html><html><head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js"></script>
        <style>
        html,body{height:100%;margin:0;padding:0;}
        #map{position:absolute;top:0;bottom:0;left:0;right:0;}
        $LEAFLET_CORE_CSS
        </style>
        </head><body>
        <div id="map"></div>
        <script>
          try {
            document.getElementById('map').style.cssText =
              "position:absolute;top:0;left:0;width:" + window.innerWidth + "px;height:" + window.innerHeight + "px;";
            var map = L.map('map').setView([${anchor.latitude}, ${anchor.longitude}], 17);
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
              attribution: '&copy; OpenStreetMap contributors',
              maxZoom: 19
            }).addTo(map);
            L.circleMarker([${anchor.latitude}, ${anchor.longitude}], {radius:8, color:'black', fillColor:'black', fillOpacity:1})
              .addTo(map).bindPopup('Ancre');
            L.circle([${anchor.latitude}, ${anchor.longitude}], {radius: $radiusMeters, color:'#6D1F2A', fill:false, weight:3})
              .addTo(map);
            var track = [$trackJs];
            if (track.length > 1) {
              L.polyline(track, {color:'#888888', weight:2}).addTo(map);
            }
            var boatMarker = null;
            window.setBoatPosition = function(lat, lon) {
              if (lat === null || lon === null) return;
              if (boatMarker) {
                boatMarker.setLatLng([lat, lon]);
              } else {
                boatMarker = L.circleMarker([lat, lon], {radius:9, color:'#1B5E20', fillColor:'#1B5E20', fillOpacity:1})
                  .addTo(map).bindPopup('Bateau');
              }
            };
            setTimeout(function() { map.invalidateSize(); }, 300);
            console.log('CARTE_OK_V2_ABSOLUTE');
            console.log('TAILLE_MAP: ' + document.getElementById('map').offsetWidth + 'x' + document.getElementById('map').offsetHeight + ' / window: ' + window.innerWidth + 'x' + window.innerHeight);
          } catch (e) {
            console.log('CARTE_ERREUR: ' + e.message);
          }
        </script>
        </body></html>
        """.trimIndent()
    }

    // Met à jour uniquement la position du bateau via JS, sans recharger toute la page.
    LaunchedEffect(boatLat, boatLon) {
        if (boatLat != null && boatLon != null) {
            webViewRef.value?.evaluateJavascript("window.setBoatPosition && setBoatPosition($boatLat, $boatLon);", null)
        }
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp),
            factory = { context ->
                WebView(context).apply {
                    setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.setSupportZoom(true)
                    settings.builtInZoomControls = false
                    settings.displayZoomControls = false
                    webChromeClient = object : android.webkit.WebChromeClient() {
                        override fun onConsoleMessage(message: android.webkit.ConsoleMessage): Boolean {
                            android.util.Log.d(
                                "WEBVIEW_MAP",
                                "${message.message()} (ligne ${message.lineNumber()} - ${message.sourceId()})"
                            )
                            return true
                        }
                    }
                    webViewClient = object : android.webkit.WebViewClient() {
                        override fun onReceivedError(
                            view: WebView?,
                            request: android.webkit.WebResourceRequest?,
                            error: android.webkit.WebResourceError?
                        ) {
                            android.util.Log.e(
                                "WEBVIEW_MAP",
                                "Erreur réseau : ${request?.url} -> ${error?.description}"
                            )
                        }
                        override fun onReceivedHttpError(
                            view: WebView?,
                            request: android.webkit.WebResourceRequest?,
                            errorResponse: android.webkit.WebResourceResponse?
                        ) {
                            android.util.Log.e(
                                "WEBVIEW_MAP",
                                "Erreur HTTP ${errorResponse?.statusCode} : ${request?.url}"
                            )
                        }
                    }
                    webViewRef.value = this
                }
            },
            update = { webView ->
                // Ne recharge le HTML complet que si son contenu a effectivement changé
                // (nouveau mouillage, rayon modifié, ou trace mise à jour) — pas à chaque tick GPS.
                if (webView.getTag() != html) {
                    webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
                    webView.setTag(html)
                }
            }
        )
    }
    Text(
        "Nécessite une connexion internet (données mobiles) pour charger le fond de carte.",
        fontSize = 11.sp,
        color = MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.padding(top = 4.dp)
    )
}

@Composable
fun HistoryOverviewMapView(history: List<AnchorHistoryEntry>) {
    if (history.isEmpty()) return

    val dateFormat = remember { SimpleDateFormat("dd/MM/yyyy HH:mm", Locale.FRANCE) }
    val markersJs = remember(history) {
        history.joinToString(",") { e ->
            val label = dateFormat.format(Date(e.setAt)).replace("'", "")
            "{lat:${e.latitude}, lon:${e.longitude}, radius:${e.radiusMeters}, label:'$label'}"
        }
    }

    val html = remember(markersJs) {
        """
        <!DOCTYPE html><html><head>
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <script src="https://cdn.jsdelivr.net/npm/leaflet@1.9.4/dist/leaflet.js"></script>
        <style>
        html,body{height:100%;margin:0;padding:0;}
        #map{position:absolute;top:0;bottom:0;left:0;right:0;}
        $LEAFLET_CORE_CSS
        </style>
        </head><body>
        <div id="map"></div>
        <script>
          try {
            document.getElementById('map').style.cssText =
              "position:absolute;top:0;left:0;width:" + window.innerWidth + "px;height:" + window.innerHeight + "px;";
            var map = L.map('map');
            L.tileLayer('https://tile.openstreetmap.org/{z}/{x}/{y}.png', {
              attribution: '&copy; OpenStreetMap contributors',
              maxZoom: 19
            }).addTo(map);
            var points = [$markersJs];
            var group = [];
            points.forEach(function(p) {
              var marker = L.circleMarker([p.lat, p.lon], {radius:7, color:'#6D1F2A', fillColor:'#6D1F2A', fillOpacity:0.8})
                .addTo(map).bindPopup(p.label);
              group.push(marker);
            });
            if (group.length > 0) {
              var fg = L.featureGroup(group);
              map.fitBounds(fg.getBounds().pad(0.3));
            } else {
              map.setView([0,0], 2);
            }
            setTimeout(function() { map.invalidateSize(); }, 300);
            console.log('CARTE_OK_V2_ABSOLUTE');
            console.log('TAILLE_MAP: ' + document.getElementById('map').offsetWidth + 'x' + document.getElementById('map').offsetHeight + ' / window: ' + window.innerWidth + 'x' + window.innerHeight);
          } catch (e) {
            console.log('CARTE_ERREUR: ' + e.message);
          }
        </script>
        </body></html>
        """.trimIndent()
    }

    Card(modifier = Modifier.fillMaxWidth()) {
        AndroidView(
            modifier = Modifier
                .fillMaxWidth()
                .height(300.dp),
            factory = { context ->
                WebView(context).apply {
                    setLayerType(android.view.View.LAYER_TYPE_SOFTWARE, null)
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.setSupportZoom(true)
                    settings.builtInZoomControls = false
                    settings.displayZoomControls = false
                    webChromeClient = object : android.webkit.WebChromeClient() {
                        override fun onConsoleMessage(message: android.webkit.ConsoleMessage): Boolean {
                            android.util.Log.d("WEBVIEW_MAP", message.message())
                            return true
                        }
                    }
                }
            },
            update = { webView ->
                webView.loadDataWithBaseURL(null, html, "text/html", "UTF-8", null)
            }
        )
    }
}
