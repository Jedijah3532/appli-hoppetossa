package com.hoppetossa.nmeadash

import kotlin.math.atan2
import kotlin.math.cos
import kotlin.math.sin
import kotlin.math.sqrt

/**
 * Règles CSS essentielles de Leaflet (positionnement/dimensionnement des tuiles, marqueurs,
 * panneaux, contrôles), intégrées directement dans le HTML plutôt que chargées depuis un fichier
 * externe — certains bloqueurs DNS/pub renvoient une réponse vide pour du CSS tiers sans jamais
 * remonter d'erreur, ce qui rendait la carte invisible malgré un JavaScript qui s'exécutait sans erreur.
 */
const val LEAFLET_CORE_CSS = """
.leaflet-pane,.leaflet-tile,.leaflet-marker-icon,.leaflet-marker-shadow,.leaflet-tile-container,
.leaflet-pane > svg,.leaflet-pane > canvas,.leaflet-zoom-box,.leaflet-image-layer,.leaflet-layer {
  position:absolute;left:0;top:0;
}
.leaflet-container {
  overflow:hidden;background:#ddd;outline-offset:1px;
  -webkit-tap-highlight-color:transparent;
}
.leaflet-tile,.leaflet-marker-icon,.leaflet-marker-shadow {
  -webkit-user-select:none;-moz-user-select:none;user-select:none;-webkit-user-drag:none;
}
.leaflet-marker-icon,.leaflet-marker-shadow { display:block; }
.leaflet-container .leaflet-overlay-pane svg,.leaflet-container .leaflet-marker-pane img,
.leaflet-container .leaflet-shadow-pane img,.leaflet-container .leaflet-tile-pane img,
.leaflet-container img.leaflet-image-layer,.leaflet-container .leaflet-tile {
  max-width:none !important;max-height:none !important;
}
.leaflet-tile { filter:inherit;visibility:hidden; }
.leaflet-tile-loaded { visibility:inherit; }
.leaflet-zoom-box { width:0;height:0;box-sizing:border-box;z-index:800; }
.leaflet-pane { z-index:400; }
.leaflet-tile-pane { z-index:200; }
.leaflet-overlay-pane { z-index:400; }
.leaflet-shadow-pane { z-index:500; }
.leaflet-marker-pane { z-index:600; }
.leaflet-tooltip-pane { z-index:650; }
.leaflet-popup-pane { z-index:700; }
.leaflet-map-pane canvas { z-index:100; }
.leaflet-map-pane svg { z-index:200; }
.leaflet-control { position:relative;z-index:800;pointer-events:auto;float:left;clear:both; }
.leaflet-top,.leaflet-bottom { position:absolute;z-index:1000;pointer-events:none; }
.leaflet-top { top:0; } .leaflet-right { right:0; } .leaflet-bottom { bottom:0; } .leaflet-left { left:0; }
.leaflet-right .leaflet-control { float:right; }
.leaflet-top .leaflet-control { margin-top:10px; }
.leaflet-bottom .leaflet-control { margin-bottom:10px; }
.leaflet-left .leaflet-control { margin-left:10px; }
.leaflet-right .leaflet-control { margin-right:10px; }
.leaflet-popup {
  position:absolute;text-align:center;margin-bottom:20px;
}
.leaflet-popup-content-wrapper {
  padding:1px;text-align:left;border-radius:12px;background:#fff;box-shadow:0 3px 14px rgba(0,0,0,0.4);
}
.leaflet-popup-content { margin:13px 24px 13px 20px;line-height:1.3;font-size:13px; }
.leaflet-popup-tip-container {
  width:40px;height:20px;position:absolute;left:50%;margin-left:-20px;overflow:hidden;pointer-events:none;
}
.leaflet-popup-tip {
  background:#fff;width:17px;height:17px;padding:1px;margin:-10px auto 0;transform:rotate(45deg);
}
.leaflet-attribution-flag { display:inline !important;vertical-align:baseline !important;width:1em;height:0.6669em; }
.leaflet-control-attribution {
  background:rgba(255,255,255,0.8);margin:0;font-size:11px;padding:0 5px;
}
"""

/** Point d'ancrage mémorisé au moment du mouillage. */
data class AnchorPoint(
    val latitude: Double,
    val longitude: Double,
    val depthAtAnchorMeters: Double?,
    val setAt: Long
)

/** Un point de trace GPS enregistré à intervalle régulier pendant la surveillance. */
data class TrackPoint(
    val latitude: Double,
    val longitude: Double,
    val timestamp: Long
)

/** Conditions de mouillage, définissant le ratio chaîne/profondeur suggéré. */
enum class ScopeCondition(val label: String, val ratio: Int) {
    LEGER("Léger", 3),
    MODERE("Modéré", 5),
    FORT("Fort", 7)
}

/** Intervalles proposés pour l'enregistrement de la trace GPS. */
enum class RecordingInterval(val label: String, val millis: Long) {
    MIN_1("1 min", 60_000L),
    MIN_5("5 min", 5 * 60_000L),
    MIN_10("10 min", 10 * 60_000L),
    MIN_30("30 min", 30 * 60_000L),
    HOUR_1("1 h", 60 * 60_000L)
}

/**
 * Distance en mètres entre deux positions GPS (formule de Haversine).
 * Suffisamment précise pour un rayon de sécurité de mouillage (quelques dizaines/centaines de mètres).
 */
fun haversineMeters(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val earthRadius = 6_371_000.0 // mètres
    val dLat = Math.toRadians(lat2 - lat1)
    val dLon = Math.toRadians(lon2 - lon1)
    val a = sin(dLat / 2) * sin(dLat / 2) +
            cos(Math.toRadians(lat1)) * cos(Math.toRadians(lat2)) *
            sin(dLon / 2) * sin(dLon / 2)
    val c = 2 * atan2(sqrt(a), sqrt(1 - a))
    return earthRadius * c
}

/**
 * Relève (angle en degrés, 0 = Nord, sens horaire) du point 2 vu depuis le point 1.
 * Utile pour placer un point sur le schéma hors-ligne (distance + angle depuis l'ancre).
 */
fun bearingDegrees(lat1: Double, lon1: Double, lat2: Double, lon2: Double): Double {
    val phi1 = Math.toRadians(lat1)
    val phi2 = Math.toRadians(lat2)
    val deltaLambda = Math.toRadians(lon2 - lon1)
    val y = sin(deltaLambda) * cos(phi2)
    val x = cos(phi1) * sin(phi2) - sin(phi1) * cos(phi2) * cos(deltaLambda)
    val theta = atan2(y, x)
    return (Math.toDegrees(theta) + 360.0) % 360.0
}

/**
 * Longueur de chaîne suggérée (mètres) pour une profondeur et un ratio donnés.
 * Approximation classique : chaîne = (profondeur + 1m de franc-bord) x ratio.
 */
fun suggestedChainLength(depthMeters: Double, ratio: Int): Double {
    val effectiveDepth = depthMeters + 1.0 // marge franc-bord / hauteur davier
    return effectiveDepth * ratio
}

/** Caractéristiques d'Hoppetossa, utilisées pour affiner les calculs de sécurité au mouillage. */
const val HOPPETOSSA_LENGTH_METERS = 14.0
const val HOPPETOSSA_WEIGHT_TONNES = 18.0

/** Décalages fixes entre l'ancre (proue) et les points de référence du bateau, mesurés vers l'arrière. */
const val GPS_ANTENNA_OFFSET_METERS = 7.0
const val COCKPIT_OFFSET_METERS = 10.0

/** D'où provient la position utilisée pour poser l'ancre, et quelle correction lui appliquer. */
enum class AnchorFixMode(val label: String, val offsetMeters: Double) {
    PROUE("Proue", 0.0),
    GPS("Gps", GPS_ANTENNA_OFFSET_METERS),
    COCKPIT("Cockpit", COCKPIT_OFFSET_METERS)
}

/**
 * Projette une position de [distanceMeters] mètres dans la direction [bearingDegrees]
 * (0° = Nord, sens horaire). Utilisé pour corriger la position de l'ancre/antenne/cockpit
 * vers la position réelle de l'ancre (à la proue), en utilisant le cap du bateau au moment
 * du mouillage.
 */
fun projectPosition(latitude: Double, longitude: Double, bearingDegrees: Double, distanceMeters: Double): Pair<Double, Double> {
    if (distanceMeters == 0.0) return latitude to longitude
    val earthRadius = 6_371_000.0
    val bearingRad = Math.toRadians(bearingDegrees)
    val latRad = Math.toRadians(latitude)
    val lonRad = Math.toRadians(longitude)
    val angularDistance = distanceMeters / earthRadius

    val newLatRad = kotlin.math.asin(
        sin(latRad) * cos(angularDistance) + cos(latRad) * sin(angularDistance) * cos(bearingRad)
    )
    val newLonRad = lonRad + atan2(
        sin(bearingRad) * sin(angularDistance) * cos(latRad),
        cos(angularDistance) - sin(latRad) * sin(newLatRad)
    )
    return Math.toDegrees(newLatRad) to Math.toDegrees(newLonRad)
}

/**
 * Distance entre l'antenne GPS (celle du réseau NMEA, utilisée pour la position) et le point où
 * l'ancre touche le fond (bord d'étrave/davier). C'est cette distance-là, et non la longueur totale
 * du bateau, qui doit servir de marge : quand le bateau pivote sur sa chaîne tendue, l'antenne se
 * retrouve à peu près alignée avec l'ancre et l'étrave, donc à (portée de chaîne + ce décalage) de
 * l'ancre — pas à (portée + longueur totale du bateau).
 */
const val GPS_ANTENNA_OFFSET_FROM_ANCHOR_METERS = 7.0

/**
 * Rayon de sécurité suggéré (mètres) à partir de la longueur de chaîne et de la profondeur :
 * portée horizontale théorique (Pythagore) + une marge pour le décalage de l'antenne GPS par
 * rapport au point d'ancrage réel, et l'imprécision GPS.
 */
fun suggestedSecurityRadius(
    chainLengthMeters: Double,
    depthMeters: Double,
    boatLengthMargin: Double = GPS_ANTENNA_OFFSET_FROM_ANCHOR_METERS
): Double {
    val horizontal = if (chainLengthMeters > depthMeters) {
        sqrt(chainLengthMeters * chainLengthMeters - depthMeters * depthMeters)
    } else 0.0
    return horizontal + boatLengthMargin
}
