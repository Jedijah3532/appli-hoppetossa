package com.hoppetossa.nmeadash

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder

/** Un message reçu par le bot Telegram (commande de l'utilisateur). */
data class TelegramUpdate(val updateId: Long, val chatId: String, val text: String)

/**
 * Envoie des messages et reçoit des commandes via l'API Bot Telegram
 * (https://core.telegram.org/bots/api). Ne nécessite aucune dépendance externe.
 */
object TelegramNotifier {

    suspend fun sendMessage(botToken: String, chatId: String, text: String): Boolean =
        withContext(Dispatchers.IO) {
            try {
                val encodedText = URLEncoder.encode(text, "UTF-8")
                val urlStr = "https://api.telegram.org/bot$botToken/sendMessage?chat_id=$chatId&text=$encodedText"
                val url = URL(urlStr)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 10_000
                connection.readTimeout = 10_000
                val responseCode = connection.responseCode
                connection.disconnect()
                val success = responseCode in 200..299
                if (!success) {
                    android.util.Log.e("TelegramNotifier", "Echec envoi Telegram, code HTTP $responseCode")
                }
                success
            } catch (e: Exception) {
                android.util.Log.e("TelegramNotifier", "Erreur envoi Telegram", e)
                false
            }
        }

    /**
     * Récupère les nouveaux messages reçus par le bot depuis [offset] (long polling : la requête
     * reste ouverte jusqu'à [timeoutSeconds] s'il n'y a rien de nouveau, pour limiter le nombre
     * de requêtes réseau). Retourne la liste des messages, triés du plus ancien au plus récent.
     */
    suspend fun getUpdates(botToken: String, offset: Long?, timeoutSeconds: Int = 25): List<TelegramUpdate> =
        withContext(Dispatchers.IO) {
            try {
                val offsetParam = if (offset != null) "&offset=$offset" else ""
                val urlStr = "https://api.telegram.org/bot$botToken/getUpdates?timeout=$timeoutSeconds$offsetParam"
                val url = URL(urlStr)
                val connection = url.openConnection() as HttpURLConnection
                connection.requestMethod = "GET"
                connection.connectTimeout = 5_000
                connection.readTimeout = (timeoutSeconds + 10) * 1000
                val responseCode = connection.responseCode
                if (responseCode !in 200..299) {
                    connection.disconnect()
                    return@withContext emptyList()
                }
                val body = connection.inputStream.bufferedReader().use { it.readText() }
                connection.disconnect()

                val root = org.json.JSONObject(body)
                val results = root.optJSONArray("result") ?: JSONArray()
                (0 until results.length()).mapNotNull { i ->
                    try {
                        val update = results.getJSONObject(i)
                        val updateId = update.getLong("update_id")
                        val message = update.optJSONObject("message") ?: return@mapNotNull null
                        val chatId = message.getJSONObject("chat").getLong("id").toString()
                        val text = message.optString("text", "")
                        TelegramUpdate(updateId, chatId, text)
                    } catch (e: Exception) {
                        null
                    }
                }
            } catch (e: Exception) {
                android.util.Log.e("TelegramNotifier", "Erreur getUpdates Telegram", e)
                emptyList()
            }
        }
}
