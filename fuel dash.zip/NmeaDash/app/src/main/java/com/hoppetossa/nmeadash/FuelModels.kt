package com.hoppetossa.nmeadash

/**
 * Modèle de données de l'ordinateur de bord gazole.
 *
 * Principe : on garde un "niveau de référence" (dernière pige ou plein complet), on y ajoute
 * les pleins, et on retranche ce que chaque consommateur a brûlé depuis (débit x temps de marche).
 * A chaque nouvelle pige, l'écart entre l'estimation et la mesure sert à affiner les débits.
 */

/** Poids initial (en heures) donné aux débits par défaut, pour qu'une première pige imprécise
 *  ne remplace pas brutalement la valeur de départ. */
const val FUEL_PRIOR_HOURS = 5.0

/** Consommation minimale entre deux mesures pour affiner un débit : 1 cm de pige = ~13 L,
 *  en dessous de 25 L l'erreur de lecture pèse plus que la mesure elle-même. */
const val FUEL_MIN_LEARN_LITERS = 25.0

enum class FuelConsumer(
    val label: String,
    val defaultRateLph: Double,
    val minRateLph: Double,
    val maxRateLph: Double
) {
    ENGINE("Moteur 1200 tr/min", 4.0, 1.0, 12.0),
    GENERATOR("Groupe 4 kW", 1.0, 0.2, 4.0),
    HEATER("Webasto 4 kW", 0.5, 0.1, 2.0)
}

data class ConsumerData(
    val rateLph: Double,                    // débit retenu (appris au fil des piges)
    val calibHours: Double = FUEL_PRIOR_HOURS,
    val runningSince: Long? = null,         // horodatage de mise en marche, null = arrêté
    val totalMs: Long = 0L,                 // horodateur total (sessions terminées)
    val msSincePige: Long = 0L,             // temps de marche depuis la dernière mesure
    val litersSincePige: Double = 0.0       // litres consommés depuis la dernière mesure
)

data class TripData(
    val startedAt: Long,
    val ms: Map<FuelConsumer, Long> = emptyMap(),
    val liters: Map<FuelConsumer, Double> = emptyMap(),
    val distanceNm: Double = 0.0,           // milles parcourus moteur en marche
    val cost: Double = 0.0
)

fun TripData.addUsage(type: FuelConsumer, dtMs: Long, addLiters: Double, pricePerLiter: Double): TripData =
    copy(
        ms = ms + (type to ((ms[type] ?: 0L) + dtMs)),
        liters = liters + (type to ((liters[type] ?: 0.0) + addLiters)),
        cost = cost + addLiters * pricePerLiter
    )

data class FuelSettings(
    val litersPerCmPerTank: Double = 6.67,  // étalonnage : +40 L = +6 cm
    val tankCount: Int = 2,                 // cuves communicantes (vannes ouvertes)
    val tankDepthCm: Double = 52.0,
    val deadZoneCm: Double = 8.0,           // zone morte sous le flotteur de la sonde (tribord)
    val gaugeRangeCm: Double = 45.0,        // course de la sonde
    val pigeOffsetCm: Double = 2.0,         // la pige ne touche pas le fond
    val pricePerLiter: Double = 2.0,
    val alertThresholdL: Double = 107.0,    // par défaut = volume sous le 0 de la jauge
    val alertEnabled: Boolean = true,
    val cruiseSpeedKn: Double = 5.5         // 1200 tr/min, mer plate
) {
    val litersPerCm: Double get() = litersPerCmPerTank * tankCount
    val capacityL: Double get() = tankDepthCm * litersPerCm
    val deadZoneL: Double get() = deadZoneCm * litersPerCm
}

data class FuelEvent(val time: Long, val text: String)

data class FuelData(
    val levelAtRefL: Double,
    val refAt: Long,
    val fillsSinceRefL: Double = 0.0,
    val consumers: Map<FuelConsumer, ConsumerData>,
    val tripA: TripData,
    val tripB: TripData,
    val settings: FuelSettings = FuelSettings(),
    val history: List<FuelEvent> = emptyList(),
    val lowAlertSent: Boolean = false
)

fun FuelData.withEvent(time: Long, text: String): FuelData =
    copy(history = (listOf(FuelEvent(time, text)) + history).take(100))
