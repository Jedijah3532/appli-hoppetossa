package com.hoppetossa.nmeadash

import android.content.Context
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import org.json.JSONArray
import org.json.JSONObject

/** Un mouillage passé : position initiale, profondeur, heure de pose et de relevage. */
data class AnchorHistoryEntry(
    val latitude: Double,
    val longitude: Double,
    val depthAtAnchorMeters: Double?,
    val setAt: Long,
    val releasedAt: Long,
    val radiusMeters: Double = 30.0,
    val track: List<TrackPoint> = emptyList()
)

/**
 * Historique des mouillages, persisté dans les SharedPreferences (survit à la fermeture de
 * l'appli et au redémarrage du téléphone, contrairement à la trace GPS qui reste en mémoire).
 */
object AnchorHistory {
    private const val PREFS_NAME = "anchor_history_prefs"
    private const val KEY_HISTORY = "history_json"

    private val _entries = MutableStateFlow<List<AnchorHistoryEntry>>(emptyList())
    val entries: StateFlow<List<AnchorHistoryEntry>> = _entries

    private var initialized = false

    /** A appeler une fois (ex: au premier affichage de l'écran mouillage) pour charger l'historique. */
    fun init(context: Context) {
        if (initialized) return
        initialized = true
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        val json = prefs.getString(KEY_HISTORY, null) ?: return
        _entries.value = parseJson(json)
    }

    /** Ajoute le mouillage qui vient d'être relevé à l'historique, et persiste. */
    fun addEntry(context: Context, entry: AnchorHistoryEntry) {
        val updated = listOf(entry) + _entries.value // le plus récent en premier
        _entries.value = updated
        persist(context, updated)
    }

    private fun persist(context: Context, list: List<AnchorHistoryEntry>) {
        val prefs = context.getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE)
        prefs.edit().putString(KEY_HISTORY, toJson(list)).apply()
    }

    private fun toJson(list: List<AnchorHistoryEntry>): String {
        val array = JSONArray()
        list.forEach { e ->
            val obj = JSONObject()
            obj.put("lat", e.latitude)
            obj.put("lon", e.longitude)
            obj.put("depth", e.depthAtAnchorMeters ?: JSONObject.NULL)
            obj.put("setAt", e.setAt)
            obj.put("releasedAt", e.releasedAt)
            obj.put("radius", e.radiusMeters)
            val trackArray = JSONArray()
            e.track.forEach { p ->
                val pointObj = JSONObject()
                pointObj.put("lat", p.latitude)
                pointObj.put("lon", p.longitude)
                pointObj.put("ts", p.timestamp)
                trackArray.put(pointObj)
            }
            obj.put("track", trackArray)
            array.put(obj)
        }
        return array.toString()
    }

    private fun parseJson(json: String): List<AnchorHistoryEntry> {
        return try {
            val array = JSONArray(json)
            (0 until array.length()).map { i ->
                val obj = array.getJSONObject(i)
                val trackArray = obj.optJSONArray("track")
                val track = if (trackArray != null) {
                    (0 until trackArray.length()).map { j ->
                        val p = trackArray.getJSONObject(j)
                        TrackPoint(p.getDouble("lat"), p.getDouble("lon"), p.getLong("ts"))
                    }
                } else emptyList()
                AnchorHistoryEntry(
                    latitude = obj.getDouble("lat"),
                    longitude = obj.getDouble("lon"),
                    depthAtAnchorMeters = if (obj.isNull("depth")) null else obj.getDouble("depth"),
                    setAt = obj.getLong("setAt"),
                    releasedAt = obj.getLong("releasedAt"),
                    radiusMeters = obj.optDouble("radius", 30.0),
                    track = track
                )
            }
        } catch (e: Exception) {
            emptyList()
        }
    }
}
