package com.hoppetossa.nmeadash

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Anchor
import androidx.compose.material.icons.filled.LocalGasStation
import androidx.compose.foundation.clickable
import kotlinx.coroutines.delay
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.util.Locale

// Palette Hoppetossa : bordeaux + sable, écriture noire
val BordeauxColor = Color(0xFF6D1F2A)
val SableColor = Color(0xFFE8DCC0)
val TextColor = Color(0xFF000000)

val HoppetossaColorScheme = lightColorScheme(
    primary = BordeauxColor,
    onPrimary = TextColor,
    primaryContainer = BordeauxColor,
    onPrimaryContainer = TextColor,
    secondary = SableColor,
    onSecondary = TextColor,
    secondaryContainer = SableColor,
    onSecondaryContainer = TextColor,
    background = SableColor,
    onBackground = TextColor,
    surface = SableColor,
    onSurface = TextColor,
    surfaceVariant = SableColor,
    onSurfaceVariant = TextColor,
    outline = BordeauxColor,
    error = BordeauxColor,
    onError = TextColor
)

enum class Screen { DASHBOARD, ANCHOR, FUEL }

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ordinateur de bord gazole : charge l'état et relance le comptage si un
        // consommateur était resté en marche (appli fermée, téléphone redémarré…).
        FuelState.init(applicationContext)
        FuelState.syncService()

        // Demande la permission de notifications (nécessaire dès Android 13 pour que le
        // service d'alarme de mouillage puisse afficher sa notification persistante).
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            registerForActivityResult(
                androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
            ) { }.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }

        // Demande la permission de localisation (GPS téléphone utilisé en secours si le
        // réseau NMEA/NEA3WiFi n'est pas connecté), puis démarre le fournisseur de position.
        registerForActivityResult(
            androidx.activity.result.contract.ActivityResultContracts.RequestPermission()
        ) { granted ->
            if (granted) PositionRepository.startPhoneGps(applicationContext)
        }.launch(android.Manifest.permission.ACCESS_FINE_LOCATION)

        setContent {
            MaterialTheme(colorScheme = HoppetossaColorScheme) {
                Surface(modifier = Modifier.fillMaxSize()) {
                    var currentScreen by remember { mutableStateOf(Screen.DASHBOARD) }
                    when (currentScreen) {
                        Screen.DASHBOARD -> DashboardScreen(
                            onOpenAnchor = { currentScreen = Screen.ANCHOR },
                            onOpenFuel = { currentScreen = Screen.FUEL }
                        )
                        Screen.ANCHOR -> AnchorScreen(onBack = { currentScreen = Screen.DASHBOARD })
                        Screen.FUEL -> FuelScreen(onBack = { currentScreen = Screen.DASHBOARD })
                    }
                }
            }
        }
    }
}

@Composable
fun DashboardScreen(onOpenAnchor: () -> Unit, onOpenFuel: () -> Unit) {
    var host by remember { mutableStateOf(NmeaRepository.host) }
    var port by remember { mutableStateOf(NmeaRepository.port.toString()) }
    var protocol by remember { mutableStateOf(NmeaRepository.protocol) }

    val data by NmeaRepository.data.collectAsState()
    val connectionState by NmeaRepository.connectionState.collectAsState()
    val statusMessage by NmeaRepository.statusMessage.collectAsState()
    val positionFix by PositionRepository.currentFix.collectAsState()
    val fuelData by FuelState.data.collectAsState()
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(Unit) {
        while (true) {
            now = System.currentTimeMillis()
            delay(5_000)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(
                "Hoppetossa — NMEA Dash",
                fontSize = 22.sp,
                fontWeight = FontWeight.Bold
            )
            Row {
                IconButton(onClick = onOpenFuel) {
                    Icon(
                        Icons.Filled.LocalGasStation,
                        contentDescription = "Ordinateur de bord gazole",
                        modifier = Modifier.size(32.dp)
                    )
                }
                IconButton(onClick = onOpenAnchor) {
                    Icon(
                        Icons.Filled.Anchor,
                        contentDescription = "Alarme de mouillage",
                        modifier = Modifier.size(32.dp)
                    )
                }
            }
        }
        Spacer(Modifier.height(16.dp))

        InstrumentCard(
            label = "Vent réel",
            value = if (data.windTrueAngleDeg != null && data.windTrueSpeedKn != null)
                String.format(Locale.FRANCE, "%.0f° / %.1f kn", data.windTrueAngleDeg, data.windTrueSpeedKn)
            else "—"
        )
        Spacer(Modifier.height(12.dp))
        InstrumentCard(
            label = "Vent apparent",
            value = if (data.windApparentAngleDeg != null && data.windApparentSpeedKn != null)
                String.format(Locale.FRANCE, "%.0f° / %.1f kn", data.windApparentAngleDeg, data.windApparentSpeedKn)
            else "—"
        )
        Spacer(Modifier.height(12.dp))
        InstrumentCard(
            label = "Profondeur",
            value = data.depthMeters?.let { String.format(Locale.FRANCE, "%.1f m", it) } ?: "—"
        )
        Spacer(Modifier.height(12.dp))
        InstrumentCard(
            label = "Vitesse surface (loch)",
            value = data.speedThroughWaterKn?.let { String.format(Locale.FRANCE, "%.1f kn", it) } ?: "—"
        )
        Spacer(Modifier.height(12.dp))
        InstrumentCard(
            label = "Vitesse fond (GPS)",
            value = data.speedOverGroundKn?.let { String.format(Locale.FRANCE, "%.1f kn", it) } ?: "—"
        )
        Spacer(Modifier.height(12.dp))
        InstrumentCard(
            label = "Position GPS" + (positionFix?.let {
                if (it.source == PositionSource.PHONE_GPS) " (téléphone)" else " (NMEA)"
            } ?: ""),
            value = positionFix?.let { formatLatLon(it.latitude, it.longitude) } ?: "—"
        )
        Spacer(Modifier.height(12.dp))
        Box(Modifier.clickable(onClick = onOpenFuel)) {
            val fuelLevel = FuelState.levelL(fuelData, now).coerceAtLeast(0.0)
            val fuelRate = FuelState.instantRateLph(fuelData).takeIf { it > 0 } ?: FuelState.engineRateLph(fuelData)
            InstrumentCard(
                label = "Gazole" + if (FuelState.anyRunning(fuelData)) " (en marche)" else "",
                value = fr("%.0f L · %.0f h", fuelLevel, fuelLevel / fuelRate)
            )
        }

        Spacer(Modifier.height(24.dp))

        ConnectionPanel(
            host = host,
            port = port,
            protocol = protocol,
            onHostChange = { host = it },
            onPortChange = { port = it },
            onProtocolChange = { protocol = it },
            connectionState = connectionState,
            statusMessage = statusMessage,
            onToggle = {
                if (NmeaRepository.isActive()) {
                    if (!AnchorState.isWatching.value) {
                        NmeaRepository.disconnect()
                    }
                } else {
                    val portInt = port.toIntOrNull()
                    if (portInt != null && portInt in 1..65535) {
                        NmeaRepository.configure(host, portInt, protocol)
                        NmeaRepository.connect()
                    }
                }
            }
        )

        Spacer(Modifier.height(16.dp))
        if (data.lastRawSentence.isNotEmpty()) {
            Text(
                "Dernière trame : ${data.lastRawSentence}",
                fontSize = 11.sp,
                modifier = Modifier.padding(top = 8.dp)
            )
        }
    }
}

/** Formate une position en degrés + minutes décimales, façon "43°25.320'N 3°36.100'E". */
fun formatLatLon(lat: Double?, lon: Double?): String {
    if (lat == null || lon == null) return "—"
    return "${formatCoord(lat, isLatitude = true)}  ${formatCoord(lon, isLatitude = false)}"
}

private fun formatCoord(value: Double, isLatitude: Boolean): String {
    val hemisphere = if (isLatitude) {
        if (value >= 0) "N" else "S"
    } else {
        if (value >= 0) "E" else "W"
    }
    val absValue = kotlin.math.abs(value)
    val degrees = absValue.toInt()
    val minutes = (absValue - degrees) * 60.0
    return String.format(Locale.FRANCE, "%d°%.3f'%s", degrees, minutes, hemisphere)
}

@Composable
fun ConnectionPanel(
    host: String,
    port: String,
    protocol: NmeaProtocol,
    onHostChange: (String) -> Unit,
    onPortChange: (String) -> Unit,
    onProtocolChange: (NmeaProtocol) -> Unit,
    connectionState: ConnectionState,
    statusMessage: String?,
    onToggle: () -> Unit
) {
    val connected = connectionState == ConnectionState.CONNECTED
    val connecting = connectionState == ConnectionState.CONNECTING

    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row {
                    FilterChipLike("UDP", protocol == NmeaProtocol.UDP) { onProtocolChange(NmeaProtocol.UDP) }
                    Spacer(Modifier.width(8.dp))
                    FilterChipLike("TCP", protocol == NmeaProtocol.TCP) { onProtocolChange(NmeaProtocol.TCP) }
                }
            }
            Spacer(Modifier.height(8.dp))
            Row(modifier = Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    value = host,
                    onValueChange = onHostChange,
                    label = { Text("IP multiplexeur") },
                    enabled = !connected && !connecting,
                    modifier = Modifier.weight(1f)
                )
                Spacer(Modifier.width(8.dp))
                OutlinedTextField(
                    value = port,
                    onValueChange = { onPortChange(it.filter { c -> c.isDigit() }) },
                    label = { Text("Port") },
                    enabled = !connected && !connecting,
                    keyboardOptions = androidx.compose.foundation.text.KeyboardOptions(
                        keyboardType = androidx.compose.ui.text.input.KeyboardType.Number
                    ),
                    modifier = Modifier.width(100.dp)
                )
            }
            Spacer(Modifier.height(12.dp))
            Button(onClick = onToggle, modifier = Modifier.fillMaxWidth()) {
                Text(
                    when {
                        connected -> "Déconnecter"
                        connecting -> "Connexion…"
                        else -> "Se connecter"
                    }
                )
            }
            val statusColor = when (connectionState) {
                ConnectionState.CONNECTED -> MaterialTheme.colorScheme.primary
                ConnectionState.ERROR -> MaterialTheme.colorScheme.error
                else -> MaterialTheme.colorScheme.onSurfaceVariant
            }
            Spacer(Modifier.height(8.dp))
            Text(
                text = statusMessage ?: connectionState.name,
                color = statusColor,
                fontSize = 13.sp
            )
        }
    }
}

@Composable
fun FilterChipLike(label: String, selected: Boolean, onClick: () -> Unit) {
    AssistChip(
        onClick = onClick,
        label = { Text(label) },
        colors = if (selected) AssistChipDefaults.assistChipColors(
            containerColor = MaterialTheme.colorScheme.primaryContainer
        ) else AssistChipDefaults.assistChipColors()
    )
}

@Composable
fun InstrumentCard(label: String, value: String) {
    Card(modifier = Modifier.fillMaxWidth()) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(label, fontSize = 14.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.height(4.dp))
            Text(value, fontSize = 28.sp, fontWeight = FontWeight.SemiBold)
        }
    }
}
