package com.hoppetossa.nmeadash

import android.Manifest
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.PackageManager
import android.content.pm.ServiceInfo
import android.os.IBinder
import androidx.core.app.NotificationCompat
import androidx.core.app.ServiceCompat
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.Job
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.cancel
import kotlinx.coroutines.delay
import kotlinx.coroutines.isActive
import kotlinx.coroutines.launch

/**
 * Service en avant-plan actif tant qu'un consommateur (moteur, groupe, Webasto) est en marche.
 * Les heures sont comptées par horodatage (FuelState), ce service sert à :
 *  - intégrer les milles parcourus moteur en marche (vitesse fond NMEA ou GPS téléphone),
 *  - lisser la vitesse pour la conso au mille,
 *  - envoyer l'alerte Telegram de niveau bas, même écran éteint.
 */
class FuelService : Service() {

    companion object {
        const val CHANNEL_ID = "fuel_channel"
        const val NOTIFICATION_ID = 1002
        private const val TICK_MS = 5_000L
    }

    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var loopJob: Job? = null

    override fun onCreate() {
        super.onCreate()
        FuelState.init(applicationContext)
        TelegramSettings.init(applicationContext)
        createNotificationChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()
        if (!FuelState.anyRunning()) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!NmeaRepository.isActive()) NmeaRepository.connect()
        if (loopJob?.isActive != true) startLoop()
        return START_STICKY
    }

    private fun startInForeground() {
        val hasLocation = checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED
        val types = if (hasLocation)
            ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC or ServiceInfo.FOREGROUND_SERVICE_TYPE_LOCATION
        else ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC
        try {
            ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), types)
        } catch (e: Exception) {
            // Redémarrage en arrière-plan : la localisation peut être refusée, on garde le reste.
            try {
                ServiceCompat.startForeground(this, NOTIFICATION_ID, buildNotification(), ServiceInfo.FOREGROUND_SERVICE_TYPE_DATA_SYNC)
            } catch (e2: Exception) {
                android.util.Log.e("FuelService", "Impossible de passer en avant-plan", e2)
            }
        }
    }

    private fun startLoop() {
        loopJob = scope.launch {
            var lastTick = System.currentTimeMillis()
            var lastNotification = 0L
            while (isActive) {
                delay(TICK_MS)
                val now = System.currentTimeMillis()
                val dtHours = (now - lastTick) / 3_600_000.0
                lastTick = now

                val d = FuelState.data.value
                if (!FuelState.anyRunning(d)) {
                    stopSelf()
                    break
                }

                if (FuelState.isRunning(d, FuelConsumer.ENGINE)) {
                    val sog = FuelState.currentSogKn()
                    FuelState.updateSmoothedSog(sog)
                    // Garde-fou : on ignore un intervalle anormalement long (téléphone en veille profonde).
                    if (sog != null && sog > 0.3 && dtHours < 0.01) FuelState.addDistance(sog * dtHours)
                } else {
                    FuelState.updateSmoothedSog(null)
                }

                FuelState.checkLowAlert(now)?.let { message ->
                    if (TelegramSettings.isConfigured()) {
                        TelegramNotifier.sendMessage(TelegramSettings.botToken.value, TelegramSettings.chatId.value, message)
                    }
                }

                if (now - lastNotification >= 30_000) {
                    lastNotification = now
                    getSystemService(NotificationManager::class.java).notify(NOTIFICATION_ID, buildNotification())
                }
            }
        }
    }

    private fun createNotificationChannel() {
        val channel = NotificationChannel(CHANNEL_ID, "Ordinateur de bord gazole", NotificationManager.IMPORTANCE_LOW).apply {
            description = "Comptage des heures moteur, groupe et chauffage"
        }
        getSystemService(NotificationManager::class.java).createNotificationChannel(channel)
    }

    private fun buildNotification(): Notification {
        val openApp = PendingIntent.getActivity(
            this, 10, Intent(this, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        return NotificationCompat.Builder(this, CHANNEL_ID)
            .setSmallIcon(android.R.drawable.ic_menu_recent_history)
            .setContentTitle("Gazole — comptage en cours")
            .setContentText(FuelState.notificationText())
            .setContentIntent(openApp)
            .setOngoing(true)
            .setOnlyAlertOnce(true)
            .build()
    }

    override fun onDestroy() {
        scope.cancel()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
