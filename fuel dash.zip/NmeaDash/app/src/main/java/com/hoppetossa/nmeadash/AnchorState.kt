package com.hoppetossa.nmeadash

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow

/**
 * Etat partagé de l'alarme de mouillage, lu et modifié à la fois par l'écran AnchorScreen
 * et par AnchorWatchService (qui tourne en arrière-plan, écran éteint).
 */
object AnchorState {

    private val _anchor = MutableStateFlow<AnchorPoint?>(null)
    val anchor: StateFlow<AnchorPoint?> = _anchor

    private val _securityRadiusMeters = MutableStateFlow(30.0)
    val securityRadiusMeters: StateFlow<Double> = _securityRadiusMeters

    private val _scopeCondition = MutableStateFlow(ScopeCondition.MODERE)
    val scopeCondition: StateFlow<ScopeCondition> = _scopeCondition

    private val _recordingInterval = MutableStateFlow(RecordingInterval.MIN_5)
    val recordingInterval: StateFlow<RecordingInterval> = _recordingInterval

    private val _track = MutableStateFlow<List<TrackPoint>>(emptyList())
    val track: StateFlow<List<TrackPoint>> = _track

    private val _isWatching = MutableStateFlow(false)
    val isWatching: StateFlow<Boolean> = _isWatching

    private val _isAlarming = MutableStateFlow(false)
    val isAlarming: StateFlow<Boolean> = _isAlarming

    private val _currentDistanceMeters = MutableStateFlow<Double?>(null)
    val currentDistanceMeters: StateFlow<Double?> = _currentDistanceMeters

    fun setAnchor(point: AnchorPoint) {
        _anchor.value = point
        _track.value = emptyList()
        _isAlarming.value = false
    }

    fun clearAnchor() {
        _anchor.value = null
        _track.value = emptyList()
        _isWatching.value = false
        _isAlarming.value = false
        _currentDistanceMeters.value = null
    }

    fun setSecurityRadius(meters: Double) {
        _securityRadiusMeters.value = meters
    }

    fun setScopeCondition(condition: ScopeCondition) {
        _scopeCondition.value = condition
    }

    fun setRecordingInterval(interval: RecordingInterval) {
        _recordingInterval.value = interval
    }

    fun setWatching(active: Boolean) {
        _isWatching.value = active
        if (!active) _isAlarming.value = false
    }

    fun setAlarming(active: Boolean) {
        _isAlarming.value = active
    }

    fun updateDistance(meters: Double?) {
        _currentDistanceMeters.value = meters
    }

    fun addTrackPoint(point: TrackPoint) {
        _track.value = _track.value + point
    }
}
